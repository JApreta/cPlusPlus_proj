/**************************************************************************************************/

/*
* File:TrendingOutput.h
* Author:judith antonio
* NetID: judithantonio
* Date:04/12/2016
*
* Description: Dafinition of the TrendingOutput class
*
*//**************************************************************************************************/

#ifndef TRENDINGOUTPUT_H
#define TRENDINGOUTPUT_H
#include "OpenInputFiles.h"
#include "Hashtag.h"
#include <vector>
#include <string>

class TrendingOutput {

private:
	
public:
	TrendingOutput();//default constructor

	int TredingOutHashtag(OpenInputFiles *InputObj, string Filename);//Open and write out the Hashtags in the output file
	
	string setRankDifference(OpenInputFiles *InputObj,int index);//calculates the rank diffrence of each Hashtag

	//spefifies the correct output format for each hashtag base in a tie or not uses the the setRankDifference method
	void OutputFormat(OpenInputFiles *InputObj, bool Tie_flag, ofstream &Outputfile, int index);

	int CreateEmptyFile(string Filename);// creates an empty output file

};

#endif