
/*
* File:OpenInputFiles.cpp
* Author: judith antonio
* NetID: judithantonio
* Date:04/12/2016
*
* Description:
Definition of of the methods that:
open the StartHash and EndHash files set all the words to lowercase and write the data of the file in a vector
Set the corresponding start and end count of each word,
sort the vector using the overloanding operator<, 
Specifies the rank of each word, and allow to acess the Hashtag vector List from others classes
*/

#include <iostream>
using namespace std;

#include "Hashtag.h"
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <cctype>
#include <algorithm>
#include "OpenInputFiles.h"

//default constructor
OpenInputFiles::OpenInputFiles()
{
	
}

//Sort the vector list with the overloading condictons
void OpenInputFiles::sortHashtags()
{
	sort(this->HashtagList.begin(), this->HashtagList.end());//use the built in sort function with the overloading operator function to sort the vector
}

/**********************************************************************************
This method Opens the endHashtag file take word by word 
uses the converttolowercase method to convert it to lowercase, 
write them in the vector Hashtaglist and update its munber of ocorrencia no file
*************************************************************************************/
int OpenInputFiles::openHashtagEndFile(string fileName)
{
	unsigned int i = 0,j=0;
	string word;
	ifstream Inputfile;//to read from the file
	int check = 0;

	Inputfile.open(fileName.c_str());//try to open the file

	if (!Inputfile.is_open())//if not succeed
		return failOpenFile;


	if (Inputfile.peek() == ifstream::traits_type::eof()) {//check if the input file is empty

		Inputfile.close();//cloce the file
		return emptyFile;
	}

	while (!Inputfile.eof()) {//run while it does not reach the end of file
		check = 0;

		Inputfile >> word;//get the word fro the file 

		if(!word.empty()){ //check if it is not empty

		converttolowercase(word);//convert to wort to lower case
		
		if (i == 0) {//for the first word
			Hashtag first_elem(word,0, 1);	//add the first word on the list	
			HashtagList.push_back(first_elem);
			i++;
		}

		else {//for the following ones

			for (j = 0; j < HashtagList.size(); j++) {

				if (word == HashtagList.at(j).getWord()) {//search if it already exist on the list
					this->HashtagList.at(j).IncrementEndCount();//if so add Endcount
					check++; //update check to control the word status
					break;			
				}
			}

			if (check == 0) {//if the word is new
				Hashtag next_elem(word,0, 1);//create a new element
				HashtagList.push_back(next_elem);	//and add it on the list					
			}		
		}

		word.clear();//clear to get a new word

		}
	}

	Inputfile.close();//close the file

	return openedFile;
}

/**********************************************************************************
This method Opens the StartHashtag file take word by word
uses the converttolowercase method to convert it to lowercase, verifies if it already exist in the
the vector Hashtaglist if not add them and update its munber of ocorrencia no file
*************************************************************************************/
int OpenInputFiles::openHashtagStartFile(string fileName)
{
	unsigned int j = 0;
	string word;
	ifstream Inputfile;//to read from the file
	int check = 0;

	Inputfile.open(fileName.c_str());//try to open the file

	if (!Inputfile.is_open())//if not succeed
		return failOpenFile;


	if (Inputfile.peek() == ifstream::traits_type::eof()) {//check if the input file is empty

		Inputfile.close();//cloce the file
		return emptyFile;
	}

	while (!Inputfile.eof()) {//run while it does not reach the end of file

		check = 0;

		Inputfile >> word;//get the word fro the file

		if(!word.empty()){//check if the word is empty

		converttolowercase(word);//call the convert mwthod and make a lowercase word

		
			for (j = 0; j < this->HashtagList.size(); j++) {

				if (word == this->HashtagList.at(j).getWord()) {//search if it already exist on the list
					
					this->HashtagList.at(j).IncrementStartCount();//if so add Startcount
					check++;//update check to control the word status
					break;
				}
			}

			if (check == 0) {//if the word is new
				Hashtag next_elem(word,1);//create a new element
				HashtagList.push_back(next_elem);//add it in the vector
			}

			word.clear();//clear to get a new word
		}
	}
	Inputfile.close();//close the file

	return openedFile;
}

//This method convert a given word to lowercase
void OpenInputFiles::converttolowercase(string &word)
{
	unsigned int  i = 0;
	for (i = 0; i < word.length(); i++)//for all letter in the word
		word[i] = static_cast<char> (tolower(word[i]));//convert it to lower case

}

//this method set all rank member of the vector to zero
void OpenInputFiles::intializationrank()
{
	unsigned int i = 0;

	for (i = 0; i < this->HashtagList.size(); i++) {

		this->HashtagList.at(i).setStartRank(0);//set all starrank to zero
		this->HashtagList.at(i).setEndRank(0);//set all endrank to zero
	}
}

//This method Specifies the StartRank of each HashTag
void OpenInputFiles::SettingStartRank()
{
	unsigned int i = 0, j = 0,k=0;
	int H_start_rank = 1, maxStartcount = 0;
	int check = 0;


	for (i = 0; i < this->HashtagList.size(); i++) {

		maxStartcount = 0; check = 0;//reset max and check for new search
		
		for (k = 0; k < this->HashtagList.size(); k++) {//this loop is to search a new maxStartcount value

			if (this->HashtagList.at(k).getStartRank() == 0 //check if the rank in this pos is still zero
				&& this->HashtagList.at(k).getStartCount()> maxStartcount) {//and if it has the startcount is greater than max

				maxStartcount = this->HashtagList.at(k).getStartCount();// update max with the startcount
			}
		}

			for (j = 0; j < this->HashtagList.size(); j++) {//this loop is to look for the hashtag with the maxStart count

				if (maxStartcount == this->HashtagList.at(j).getStartCount()) {//if found

					this->HashtagList.at(j).setStartRank(H_start_rank);//set the rank of the hashtag
					check++;//update to control the rank number

				}
			}
			if (check != 0)//if a hashtag rank was updated
				H_start_rank++;//increas the Hrank 
		}
	}

//This method Specifies the EndRank of each HashTag
void OpenInputFiles::SettingEndRank( )
{
	unsigned int i = 0, j = 0, k = 0;
	int H_end_rank = 1, maxendCount = 0;
	int check = 0;


	for (i = 0; i < this->HashtagList.size(); i++) {
		maxendCount = 0; check = 0;//reset maxensCount and check for new search

		for (k = 0; k < this->HashtagList.size(); k++) {//this loop is to search a new maxEndcount value

			if (this->HashtagList.at(k).getEndRank() == 0 //if the rank of this position wasn't assign yet
				&& this->HashtagList.at(k).getEndCount()> maxendCount//and its endcount is greater than the maxendcount
				&& this->HashtagList.at(k).getEndCount()!=0) {//and if exist in endHashtag file

				maxendCount = this->HashtagList.at(k).getEndCount();//update maxendCount with the greater EndCount
			}
		}

		for (j = 0; j < this->HashtagList.size(); j++) {//this loop is to look for the hashtag with the maxStart count

			if (maxendCount == this->HashtagList.at(j).getEndCount()) {//if found

				this->HashtagList.at(j).setEndRank(H_end_rank);// set the Endrank of hashtag
				check++;//update to control the rank number
			}
		}

		if (check != 0)//if a hashtag rank was updated
			H_end_rank++;//increas the Hrank 
	}
}

//this method returns the HashtagList vector
vector<Hashtag> OpenInputFiles::getHashtagList() const
{
	return this->HashtagList;//return the hashtagvectorlist
}



