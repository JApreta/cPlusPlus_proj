/*
* File: main.cpp
* Author : judith antonio
* NetID : judithantonio
* Date : 4 /12/2016
*
* Description : thsi file holds the main function which execute the methods of others classes as need.
*/

#include <iostream>
using namespace std;

#include "Hashtag.h"
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <cctype>
#include "TrendingOutput.h"
#include "OpenInputFiles.h"

int main(int argc, char *argv[]) {

	int StartinputFile = 0, EndinputFile = 0,TrendingOut=0;

	//creates and intialize all classes objects as needed
	Hashtag Hashtag_obj;//crates an object of the Hashtag class
	OpenInputFiles OpenInputFiles_obj;//creates an object of the OpenInputFiles class
	TrendingOutput TrendingOutput_obj;//creates an object of the  TrendingOutput class

	if (argc != 4) {//check the argument #
		cout << "Usage: trending startHashtagFile endHashtagFile trendFile" << endl;
		return 1;
	}

	EndinputFile = OpenInputFiles_obj.openHashtagEndFile(argv[2]);//try to open the HashtagEndFile

	if (EndinputFile == failOpenFile) {//check if opened successfuly
		cout << " Could not read EndHashtagFile file " << argv[2] << endl;
		return 1;
	}

	if (EndinputFile == emptyFile) {//if it is empty

		TrendingOut = TrendingOutput_obj.CreateEmptyFile(argv[3]);//try to create an empty output file

		if (TrendingOut == failOpenFile) //check if created successfuly
			cout << " Could not open TrendingHashtagFile file " << argv[3] << endl;
		return 1;
	}

	StartinputFile = OpenInputFiles_obj.openHashtagStartFile(argv[1]);//try to open the HashtagStartFile

	if (StartinputFile == failOpenFile) {//check if opened successfuly
		cout << " Could not read startHashtagFile file " << argv[1] << endl;
		return 1;
	}

	OpenInputFiles_obj.sortHashtags();//sort the vector
	OpenInputFiles_obj.intializationrank();//set all rank to zero initially
	OpenInputFiles_obj.SettingEndRank();//Find the appropiate  EndRank of each hashtag
	OpenInputFiles_obj.SettingStartRank();//Find the appropiate  StartRank of each hashtag

	TrendingOut = TrendingOutput_obj.TredingOutHashtag(&OpenInputFiles_obj, argv[3]);//try to open the Hashtag output file


	if (TrendingOut == failOpenFile) {//check if opened successfuly
		cout << " Could not open TrendingHashtagFile file " << argv[3] << endl;
		return 1;
	}

return 1;
}