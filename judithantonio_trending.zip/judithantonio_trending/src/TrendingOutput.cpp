
/*
* File: TrendingOutput.cpp
* Author: judith antonio
* NetID: judithantonio
* Date:04/12/2016
*
* Description:
This file contains the implementation of the method of the class TrendingOutput
that: Creates an empty file, Specifies the correct output for each hashtag, 
calculates the rank difference and write the hashTags in the output File

*/

#include <iostream>
using namespace std;
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <cctype>
#include <algorithm>
#include "Hashtag.h"
#include "OpenInputFiles.h"
#include "TrendingOutput.h"

TrendingOutput::TrendingOutput()
{

}

//This method opens the output file,check for tie and write the hashtag in the outfile uses OutputFormat method
int TrendingOutput::TredingOutHashtag(OpenInputFiles *InputObj, string Filename)
{
	unsigned int i = 0;

	bool Tie_flag = false;
	ofstream Outputfile;

	Outputfile.open(Filename.c_str());

	if (!Outputfile.is_open())
		return failOpenFile;

	else {

		for (i = 0; i < (*InputObj).getHashtagList().size(); i++) {

			Tie_flag = false;//reset flag to false for each interaction

			if((*InputObj).getHashtagList().at(i).getEndCount()!=0){//if the word exist in the output file

				if (i == 0) {//for the first word
				
					if (i < (*InputObj).getHashtagList().size() - 1 //check if exist a next word
						&& (*InputObj).getHashtagList().at(i).getEndRank() // and  if there is tie with the nxt word
						== (*InputObj).getHashtagList().at(i + 1).getEndRank())

					Tie_flag = true;//if so
				     OutputFormat(InputObj, Tie_flag, Outputfile, i);// call  OutputFormat to write the word in the output file with the correspondent format			

			}

			else {//for the following words

				if ((*InputObj).getHashtagList().at(i).getEndRank() //check if there is a tie with the previous 
					== (*InputObj).getHashtagList().at(i - 1).getEndRank()
					|| ( i < (*InputObj).getHashtagList().size()-1 // && check the vector range before compare with the next word
					&& (*InputObj).getHashtagList().at(i).getEndRank() //check if there is a tie with the nxt word
					== (*InputObj).getHashtagList().at(i + 1).getEndRank()))
					
					Tie_flag = true;//if so
				    OutputFormat(InputObj, Tie_flag, Outputfile, i);//write the word in the output file with the correspondent format			
			
			 }
			}
		}

	}

	Outputfile.close();//close the file
	return openedFile;
}

//This method calculate the rank diffrence and return the appropiate format for the rank output
string TrendingOutput::setRankDifference(OpenInputFiles *InputObj, int index)
{
	
	int rankDiffer = 0; 
	string finalRank = "";
	stringstream SS;
	

		if ((*InputObj).getHashtagList().at(index).getEndCount() != 0) {//if the wrd exist in outtput file

			if ((*InputObj).getHashtagList().at(index).getStartCount() != 0) {//and on the input file

				rankDiffer = (*InputObj).getHashtagList().at(index).getStartRank() //calculate the rank diffrence
					       - (*InputObj).getHashtagList().at(index).getEndRank();
				
				SS << rankDiffer;//convert the rank difference to string
			

				if (rankDiffer >= 0)//if the rank is zero or greater
					finalRank = " (+" + SS.str() + ')';//create a classi-->(+rank)to_string(rankDiffer)
				else
					finalRank = " (" + SS.str() + ')';//otherwise create a classi-->(-rank)
			}
			else
				finalRank = " (new)";//if the word only exist in the output file
		}

	
	return finalRank;//return the final rank format
}

//This method spefifies the correct output format for each hashtag base in a tie or not uses the the setRankDifference method
void TrendingOutput::OutputFormat(OpenInputFiles * InputObj, bool Tie_flag, ofstream &Outputfile, int index)
{

	if (Tie_flag == true) {//if there is a rank tie

		Outputfile << "T"//write the output as TR: W (RD)
 
			<< (*InputObj).getHashtagList().at(index).getEndRank() << ": "
			<< (*InputObj).getHashtagList().at(index).getWord()
			<< setRankDifference(InputObj, index) << endl;
	}

	else {//otherwise 
		Outputfile //write the output as R: W (RD)
			<< (*InputObj).getHashtagList().at(index).getEndRank() << ": "
			<< (*InputObj).getHashtagList().at(index).getWord()
			<< setRankDifference(InputObj, index) << endl;

	}

}

//This method creates an empty output file
int TrendingOutput::CreateEmptyFile(string Filename)
{
	ofstream Emptyfile;
	Emptyfile.open(Filename.c_str());

	if (Emptyfile.is_open()) {//if the file was opened
		Emptyfile.close();//closed
		return openedFile;
	}
	else//if not
		return failOpenFile;
}
