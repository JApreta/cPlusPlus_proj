/**************************************************************************************************/

/*
* File:OpenInputFiles.h
* Author:judith antonio
* NetID: judithantonio
* Date:04/02/2016
*
* Description: Dafeinition of the OpenInputFiles class
*
*//**************************************************************************************************/

#ifndef OPENINPUTFILES_H
#define OPENINPUTFILES_H

#include "Hashtag.h"
#include <vector>
#include <string>

class OpenInputFiles {

private:
	vector <Hashtag> HashtagList;   //vector that holds a list of hashtags elem
	
public:
	OpenInputFiles(); // Default constructor

	void sortHashtags();//sort the hashtag vector with the <operator conditions

	int openHashtagStartFile(string fileName);//opent the starhashtagFile and put the words in the vector with the respective count

	int openHashtagEndFile(string fileName);//open the endhashtagFile and put the words in the vector with the respective count
	 
	void converttolowercase(string &word);//convert the words read from the file to lowercase

	void intializationrank();//set all hashtag's rank to zero in the vector

	void SettingStartRank();//set the the apropriate startrank based in the startcount

	void SettingEndRank();//set the the apropriate Endrank based in the endcount

	vector <Hashtag> getHashtagList()const;//return the hashtag vector

};

#endif