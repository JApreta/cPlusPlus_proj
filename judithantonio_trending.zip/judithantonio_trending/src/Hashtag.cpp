/*
* File: Hashtag.cpp
* Author: judith antonio
* NetID: judithantonio
* Date:04/12/2016
*
* Description: This file cointans the definition of all the HashTag class members
*/

#include <iostream>
using namespace std;

#include "Hashtag.h"

//this constructor initialize only the word elem
Hashtag::Hashtag(string word)
{
	this->word = word;
}

//this constructor initiatlize all variable members
Hashtag::Hashtag(string word, int startCount, int endCount)
{

	this->word = word;
	this->startCount = startCount;
	this->endCount = endCount;
}

//default constructor
Hashtag::Hashtag()
{

}

//This method is used return the word elem
string Hashtag::getWord() const
{
	return this->word;
}

//This method is used returnse the EndCount elem
int Hashtag::getStartCount() const
{
	return this->startCount;
}

//This method is used to returns the StartCount elem
int Hashtag::getEndCount() const
{
	return this->endCount;
}

//This method is used to return the StartRank elem
int Hashtag::getStartRank() const
{
	return this->startRank;
}

//This method is used to return the EndRank elem
int Hashtag::getEndRank() const
{
	return this->endRank;
}

//This method is used to update the StartRank elem
void Hashtag::setStartRank(int rank)
{
	this->startRank = rank;
}

//This method is used to update the Endrank elem
void Hashtag::setEndRank(int rank)
{
	this->endRank = rank;
}

//This method is used to update the word elem
void Hashtag::setWord(string word)
{
	this->word = word;
}

//This method is used to update the StartCount elem
void Hashtag::IncrementStartCount()
{
	this->startCount= this->startCount + 1;
}

//This method is used to update the EndCount elem
void Hashtag::IncrementEndCount()
{
	this->endCount++;
}

//this method is used to overlaod the< operator with specific conditions
bool Hashtag::operator<(const Hashtag & rhs) const
{ 
	bool check = false;

	if (rhs.endCount <  this->endCount)//check if the rhs' end count is less than the lhs end count
		check = true;

	//check i If the rhs' end count is equal to the lhs' end count, and both end counts are not 0, and the lhs' word is less than rhs' word alphabetically 
		if((rhs.endCount == this->endCount) && rhs.endCount != 0 && this->endCount !=0 &&(rhs.word > this->word))
		check = true;
	
		//check If both the rhs' and the lhs' end counts are 0, and the rhs' start count is less than the lhs' start count
	 if((rhs.endCount == 0 && this->endCount==0) &&(rhs.startCount < this->startCount))
		check = true;

	 //check If both the rhs' and lhs' end counts are 0, and the rhs' start count is equal to the lhs' start count, and the lhs' word is less than the rhs' word alphabetically
	 if ((rhs.endCount == 0 && this->endCount == 0) && (rhs.startCount == this->startCount) &&(rhs.word > this->word))
		check = true;

	return check;
}
