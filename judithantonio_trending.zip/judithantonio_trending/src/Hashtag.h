/**************************************************************************************************/

/*
* File: Hashtag.h
* Author:judith antonio
* NetID: judithantonio
* Date:04/12/2016
*
* Description: 
*              Definiton of the HashTag class.
*/

/**************************************************************************************************/

#ifndef HASHTAG_H
#define HASHTAG_H
#include <vector>
#define failOpenFile 1
#define openedFile 0
#define emptyFile 2
class Hashtag {
private:
	string word;      // The hashtag itself
	int startCount;   // Number of occurrences in start file
	int endCount;     // Number of occurrences in end file
	int startRank;    // Rank in start file
	int endRank;      // Rank in end file

public:
	Hashtag(string word); // Default constructor
	Hashtag(string word, int startCount, int endCount = 0);//costumized constructor
	Hashtag();
	
	// Getter and setter functions for hashtag word, counts, and ranks
	string getWord() const;// retuns the word member
	int getStartCount() const;//returns the StartCount member
	int getEndCount() const;//returns the EndCount member
	int getStartRank() const;//returns the StartRank member
	int getEndRank() const;//returns the EndRank member
	void setStartRank(int rank);//update the Startrank member
	void setEndRank(int rank);//update the Endrank member
	void setWord(string word);//update theword member
	// Functions to increment start or end counts
	void IncrementStartCount();
	void IncrementEndCount();

	// Overloaded < operator for Hashtag objects
	bool operator<(const Hashtag& rhs) const;

	
};

#endif