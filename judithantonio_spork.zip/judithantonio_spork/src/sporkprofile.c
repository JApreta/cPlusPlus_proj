/**************************************************************************************************/

/*
 * File: sporkprofile.c
 * Author:judith Antonio
 * NetID:judithantonio
 * Date:2/9/2016
 *
 * Description: Function definitions for reading, processing, and writing Spork profiles.
 *
 */

/**************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "sporkprofile.h"

/**************************************************************************************************/

/* Reads up to maxProfiles Spork profiles from an input file specified by fileName. Functions reads
 * the input file line-by-line using the format:
 *
 *    BusinessName X.XX Y.YY R.RR A
 *
 * BusinessName is the name of the restauarant/business. The buseiness name will not include any
 * whitespace characters
 *
 * X.XX represents the X location in miles using a Cartesian coodinate system
 *
 * Y.YY represents the Y location in miles using a Cartesian coodinate system
 *
 * R.RR represents the average rating for the business
 *
 * A is the advertising level, which should 0, 1, or 2
 *
 * Alpha submission: ReadSporkDataFromFile() function should initialize isNearby and isGood
 *                   to true and initialize distMiles to 0.0 for all profile entries.
 *                   Note: This requirement is different for the final project submission.
 *
 * Project submission: ReadSporkDataFromFile() function should initialize isNearby and isGood
 *                     to false for all profile entries.
 *                     Note: This requirement is different for the alpha project submission.
 *
 * Returns: The number of Spork profiles read from the file. If the input file could not be opened,
 *          the function returns -1.
 *
 */

int ReadSporkDataFromFile(SporkProfile sporkProfiles[], int maxProfiles, char *fileName) {

	FILE * inp = NULL;
	SporkProfile aux;
	char entry[1000], extra[100];
	int check = 0, total_entries = 0,valid_entry=0;
	inp = fopen(fileName, "r");//try open the file

	if (inp == NULL)//if does not exist
		return -1;

	else{
		while (!feof(inp) && (total_entries < maxProfiles)){//execute if does not reaxh the end of file or 500 entries

			fgets(entry, 1000, inp);//get the entries line by line

			total_entries++;//count the total num of entries

			check= sscanf(entry, "%s %lf %lf %lf %d %s", //convert the entry to its aproprit values
				aux.businessName,&aux.locX , &aux.locY, &aux.avgRating, &aux.adLevel,extra);
			
			if (check == 5 && (aux.adLevel >= 0 && aux.adLevel <= 2)) {//check if the entry is valid
				//if it is execute the lines below
				aux.isGood = false;
				aux.isNearby = false;
				aux.distMiles = 0.0;
				sporkProfiles[valid_entry++] = aux;

			}
	}
		///printf("%d", valid_entry);
		fclose(inp);
		return valid_entry;//return the totaol num of valid entries
}
}
/**************************************************************************************************/

/*
 * Determines if each business is nearby the user,  sets the Spork profile's isNearby flag to
 * true (is nearby) or false (not nearby), and stores the distance in miles in the Spork profile.
 *
 * userLocX, userLocY: Indicates the x and y coordiante of the user's location
 * maxDist: Indicates the maxmimum distance between the user and a nearby business
 *
 */
void FindNearbyBusinesses(SporkProfile sporkProfiles[], int numProfiles,
                          double userLocX, double userLocY, double maxDist) {

	int i;

	for (i = 0; i < numProfiles; i++) {
		sporkProfiles[i].distMiles =//calculate the distance 
			sqrt(pow((userLocX - sporkProfiles[i].locX), 2) + 
				pow((userLocY - sporkProfiles[i].locY), 2));

		if (//check if maxDist>=sporkProfiles[i].distMiles
			maxDist >= sporkProfiles[i].distMiles)

			sporkProfiles[i].isNearby = true;//if it is flag up
		else
			sporkProfiles[i].isNearby = false;//if not flag down

	}



}


/**************************************************************************************************/

/*
 * Determines if each business is good based on the user's minimum required average rating.
 * Sets the Spork profile's isGood flag to true if the business' avgRating is greater than or
 * equal to minRating, and false otherwise.
 *
 */
void FindGoodBusinesses(SporkProfile sporkProfiles[], int numProfiles,
                        double minRating) {

	int i;

	for (i = 0; i < numProfiles; i++) {

		if ( //check ifminRating<=sporkProfiles[i].avgRating
			sporkProfiles[i].avgRating >= minRating)

			sporkProfiles[i].isGood = true;//if it is flag up
		else
			sporkProfiles[i].isGood = false;//if not flag down
	}


   
}

/**************************************************************************************************/
/*******************************************************************************************
 * this function gathers all the Businesses that are both good and near by in a singe array   *
********************************************************************************************/
int FindGoodandNearbyBusinesses(SporkProfile sporkProfiles[], int numProfiles,
	SporkProfile goodAndnearby[]) {

	int i,count=0;

	for (i = 0; i < numProfiles; i++) {
		if (sporkProfiles[i].isGood == true && //if the entry is both good and nearby
			sporkProfiles[i].isNearby == true) {

			goodAndnearby[count++] = sporkProfiles[i];//update the arry
		}
	}
	return count;
}


/*
 * Returns the index of the Spork profile that is neary, good, and has the highest adLevel. If
 * there is a tie, the index of the first entry found with the highest ad level should be returned.
 * If no businesses are nearby and good, the function will return -1.
 *
 */

int GetIndexMaxSponsor(SporkProfile sporkProfiles[], int numProfiles) {
	
	int i, maxIndex=-1, total =0,greater_adlevel=0;
	SporkProfile goodAndnearby[500];
	
	//get all goodAndnearby Businesses
	total=FindGoodandNearbyBusinesses(sporkProfiles, numProfiles, goodAndnearby);
	
	if(total !=0){

		//check for the one with greater adlevel
		greater_adlevel = goodAndnearby[0].adLevel;

		for (i = 0; i < total; i++) {
		
			if (goodAndnearby[i].adLevel >= greater_adlevel)
					greater_adlevel = goodAndnearby[i].adLevel;
			
		}

		for (i = 0; i < total; i++) {	
			
			//check get position of the one with greater adlevel
				if (goodAndnearby[i].adLevel >= goodAndnearby[i + 1].adLevel)
					maxIndex = i;
				else
					maxIndex = i+1;

				if (goodAndnearby[i].adLevel == greater_adlevel || goodAndnearby[i + 1].adLevel == greater_adlevel)
					break;//break the search if greater index found
		}

		
	}
	
   return maxIndex;
}

/**************************************************************************************************/

/*
 * Writes all good and nearby business to an output file specified by fileName using the format:
 *
 *    BusinessName R.RR D.DD
 *
 * R.RR is the average rating with exactly two decimal digits of precision.
 * D.DD is the distance in miles with exactly two decimal digits of precision.
 *
 * If maxSponsorIndex is not -1, the cooresponding profile entry will be output first. All other
 * nearby and good profiles will be output in the order they are stored in the sporkProfiles array.
 *
 * Each entry should be separated by a single tab character (\t), and each line should end
 * with a single newline (\n).
 *
 * Returns: -1 if the output file could not be opened, and 0 otherwise.
 *
 */
int WriteSporkResultsToFile(SporkProfile sporkProfiles[], int numProfiles, int maxSponsorIndex, char *fileName) {
   
	FILE * out = NULL;

	int i = 0, lines = 0, total = 0;
	SporkProfile goodAndnearby[500];

	out = fopen(fileName, "w+");

	
	total = FindGoodandNearbyBusinesses(sporkProfiles, numProfiles, goodAndnearby);


	if (out == NULL)
		return -1;

	else {

		//printf("%d\n",total);
		//printf("%s\n", aux[maxSponsorIndex].businessName);
		if (maxSponsorIndex != -1) {
			fprintf(out, "%s\t%.2lf\t%.2lf\n", 
				goodAndnearby[maxSponsorIndex].businessName, 
				goodAndnearby[maxSponsorIndex].avgRating, 
				goodAndnearby[maxSponsorIndex].distMiles);
		}

		for (i = 0; i < total;i++){
			if(i!= maxSponsorIndex)
				fprintf(out, "%s\t%.2lf\t%.2lf\n", 
					goodAndnearby[i].businessName,
					goodAndnearby[i].avgRating,
					goodAndnearby[i].distMiles);
		
		
		}

		fclose(out);
		return 0;
	}
	
}

/**************************************************************************************************/
