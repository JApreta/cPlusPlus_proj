#include <iostream>
using namespace std;
#include "velociplotter.h"
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include "GpsPosition.h"

int main(int argc, char *argv[]) {

	int inputFile = 0, outputFile = 0;
	bool valide = false;
	velociplotter Obj;
	
	//creates and intialize all classes objects as needed

	

	if (argc != 3) {//check the argument #
		cout << "Usage: velociplotter gpsLogFile gpsPlotDataFile" << endl;
		return 1;
	}

	inputFile = Obj.openFile(argv[1]);//try to open the input file from the velociplotter class

	if (inputFile == failOpenFile) {//check if opened successfuly
		cout << " Could not read gpsLogFile file " << argv[1] << endl;
		return 1;
	}

	if (inputFile == emptyFile) {//check if the input file is empty if so

		outputFile = Obj.CreateEmptyFile(argv[2]);

		if (outputFile == failOpenFile) {//check if succeed
			cout << " Could not creaete Output file " << argv[2] << endl;
		}//cout << " The gpsLogFile is empty " << argv[1] << endl;
		return 1;
	}

	if (Obj.validate() == false) {
		outputFile = Obj.CreateEmptyFile(argv[2]);

		cout << "Error: The Time input from gpsLogFile is not increasing" << endl;
		return 1;
	}

	outputFile = Obj.openOutputFile(argv[2]);

	/*int i = 0;
	
		for (i = 0; i < Obj.getdataInput().size(); i++){

			GpsPosition ob(Obj.getdataInput().at(i).GetLatitude(), Obj.getdataInput().at(i).GetLongitude(), Obj.getdataInput().at(i).GetTime());
			if (i<Obj.getdataInput().size() - 1){
		cout << Obj.getdataInput().at(i+1).GetTime()<<"  ";
		
		cout << (ob.CalcDistanceKmTo(Obj.getdataInput().at(i+1)))*3600 /((Obj.getdataInput().at(i+1).GetTime()-Obj.getdataInput().at(i).GetTime()))
			<<endl;
	}
		}*/
	
	/*	if (inputFile == emptyFile) {//check if the input file is empty if so

	outputFile = datasinkObj.CreateEmptyFile(argv[2]);// try to create an empty output file

		if (outputFile != 0) {//check if succeed
			cout << " Could not create empty OutputState file " << argv[2] << endl;

		}
		return 1;
	}
	*/
	
	
	return 1;
}
