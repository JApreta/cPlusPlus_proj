#ifndef VELOCIPLOTTER_H
#define VELOCIPLOTTER_H
/*************/
/*
* File: DataSource.h
* Author: judith antonio
* NetID: judithantonio
* Date:03/21/2016
*
* Description: Definition of DataSource class. this class contains declaration of function to get
the data from the file
the private vector from this class,
the size of the vector,
to sort the vector data and to validate it
*/


#include <vector>
#include<string>
#include "GpsPosition.h"
class velociplotter {
private:
	vector <GpsPosition> dataInput;
	vector <double> DistanceVector;

public:
	velociplotter();
	unsigned long timeconversor(double UTC_Time);
	double Latitudeconversor(double Latitude);
	double Longitudeconversor(double Longitude);
	vector <GpsPosition> getdataInput()const;//return the input vector
	int openFile(string Filename);//open the file and paste the datafile to the vector
	
	bool validate();

	int openOutputFile(string Filename);

	int CreateEmptyFile(string Filename);

};
#endif