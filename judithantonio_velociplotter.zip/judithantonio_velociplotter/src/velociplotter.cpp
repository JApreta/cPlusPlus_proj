#include <iostream>
using namespace std;
#include "velociplotter.h"
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include "GpsPosition.h"

velociplotter::velociplotter()
{
}

unsigned long velociplotter::timeconversor(double UTC_Time)
{
	int Time = static_cast<int> (UTC_Time);
	unsigned int  hour=0, min=0, sec=0;
	unsigned long timeineSec = 0;
	hour = Time / 10000;
	min = (Time % 10000) / 100;
	sec = (Time % 10000) % 100;

	timeineSec = static_cast<unsigned long> (sec +( 3600 * hour) + (min * 60));


	return timeineSec;
}

double velociplotter::Latitudeconversor(double Latitude)
{
	double Lat_Decimal_degree = 0.0;
	int degree = Latitude / 100;
	double minutes = (((Latitude / 100) - degree) * 100) / 60;

	Lat_Decimal_degree = degree + minutes;
	return Lat_Decimal_degree;
}

double velociplotter::Longitudeconversor(double Longitude)
{
	double Long_Decimal_degree = 0.0;
	int degree = Longitude / 100;
	double minutes = (((Longitude / 100) - degree) * 100) / 60;

	Long_Decimal_degree = degree + minutes;
	return Long_Decimal_degree;

}

vector<GpsPosition> velociplotter::getdataInput() const
{
	return dataInput;
}

int velociplotter::openFile(string Filename)
{
	unsigned int i = 0;
	double latitude=0.0,latDegree=0.0;
	double longitude=0.0,longDegree=0.0;
	double time = 0.0;
	char letter=' ';
	int timeSec=0;
	istringstream inputLine;// to read from a string
	string line = " ", gpstype = "";//to save each line from the file
	ifstream Inputfile;//to read from the file

	Inputfile.open(Filename.c_str());//try to open the file

	if (!Inputfile.is_open())//if not succeed
		return failOpenFile;


	if (Inputfile.peek() == ifstream::traits_type::eof()) {//check if the input file is empty

		Inputfile.close();//cloce the file
		return emptyFile;
	}

	while (!Inputfile.eof() && getline(Inputfile, line).good()) {//run while it does not reach the end of file and doesn't fail to read a line

		if(!line.empty()){
		inputLine.str(line);//updated the stringstream with the line read from the file

		while (letter != ',') {
			inputLine >> letter;
			gpstype += letter;
		}

		if(gpstype =="$GPGGA," &&line.size()> 66){
			//cout << line.size()<<endl;
			inputLine >> time;
			
			inputLine >> letter;//read the time value from the sstrem

		inputLine >> latitude >> letter >> letter >> letter;//read the velocity value from sstream
		inputLine >> longitude;//read the angle value from the sstream
		
		timeSec= timeconversor(time);
		latDegree = Latitudeconversor(latitude);
		longDegree = Longitudeconversor(longitude);
		GpsPosition newElem(latDegree, longDegree, timeSec);

		this->dataInput.push_back(newElem);
		
		cout << this->dataInput.at(i).GetTime() << " " 
	//	<< this->dataInput.at(i).GetLongitude()
		//	<< " " << this->dataInput.at(i).GetLatitude() 
		<< endl;
		
		i++;
			}
		letter = ' ';
		gpstype.clear();
		inputLine.clear();
	}
	}


	Inputfile.close();//close the file

	return openedFile;
}


bool velociplotter::validate()
{
	bool check = false;
	unsigned int i = 0;

	for (i = 0; i < this->dataInput.size(); i++) {

		if (i < this->dataInput.size() - 1) {
			if (static_cast<signed>(this->dataInput.at(i + 1).GetTime() - this->dataInput.at(i).GetTime())>0){
				check = true;
				//cout << (this->dataInput.at(i + 1).GetTime() - this->dataInput.at(i).GetTime()) << endl;
			}
			else {
				check = false;
				break;
			}
		}
	}
	return check;
}

int velociplotter::openOutputFile(string Filename)
{
	unsigned int i = 0;
	int delta_t = 0,j=0;
	vector<double> Speed(this->dataInput.size());
	ofstream Outputfile;
	Outputfile.open(Filename.c_str());

	if (!Outputfile.is_open())
		return failOpenFile;


		for (i = 0; i < getdataInput().size(); i++) {

		//creates an object from the GpsPosition with the current latitude, longitude and time
	    GpsPosition ob(getdataInput().at(i).GetLatitude(), getdataInput().at(i).GetLongitude(), getdataInput().at(i).GetTime());
		
		
		
		if (i<getdataInput().size() - 1) {

			
			Speed.at(i) = (ob.CalcDistanceKmTo(getdataInput().at(i + 1))) * 3600 / ((getdataInput().at(i + 1).GetTime() - getdataInput().at(i).GetTime()));


				delta_t = getdataInput().at(i + 1).GetTime() - getdataInput().at(i).GetTime();
			

				//cout << delta_t << endl;
				
			if(delta_t == 1 ){

				//cout << getdataInput().at(i + 1).GetTime() << "  "
					//cout<< Speed.at(i)
				//	<< endl;
			Outputfile << getdataInput().at(i + 1).GetTime() << "  "
			           << Speed.at(i) << endl;
			}

			else {
				for (j = 1; j <= delta_t ; j++) {

					Outputfile << getdataInput().at(i).GetTime() + j << "  "
						       << Speed.at(i) << endl;

					//cout << getdataInput().at(i + 1).GetTime()+j << "  "
					//	cout<< Speed.at(i) 
					//	<< endl;
				}
	

			}
		}
		}

	
	Outputfile.close();
	return openedFile;
}
int velociplotter::CreateEmptyFile(string Filename)
{
	ofstream Emptyfile;
	Emptyfile.open(Filename.c_str());

	if (Emptyfile.is_open()) {
		Emptyfile.close();
		return openedFile;
	}
	else
		return failOpenFile;
}
