#ifndef GPSPOSITION_H
#define GPSPOSITION_H
/*************/
/*
* File: DataSource.h
* Author: judith antonio
* NetID: judithantonio
* Date:03/21/2016
*
* Description: Definition of DataSource class. this class contains declaration of function to get
the data from the file
the private vector from this class,
the size of the vector,
to sort the vector data and to validate it
*/
#define failOpenFile 1
#define openedFile 0
#define emptyFile 2


class GpsPosition {
    
private:
   double latitude;
   double longitude;
   unsigned long timeSeconds;
   
public:
   GpsPosition();
   GpsPosition(double latitude, double longitude, unsigned long timeSeconds);

   double GetLatitude();
   double GetLongitude();
   unsigned long GetTime();
   
   void SetLatitude(double latitude);
   void SetLongitude(double longitude);
   void SetTime(unsigned long timeSeconds);
   
   double CalcDistanceKmTo(GpsPosition toPosition);
};
#endif;
