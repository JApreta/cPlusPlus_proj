//----------------------------------------------------------------------//
// Author:         Judith Antonio
//                 (adpated from code by Jonathan Sprinkle)
// Net ID:         judithantonio
// Date:           06 January 2016
// Project Number: 0
// Project Name:   echoer
//
// Contains the main function.
//----------------------------------------------------------------------//

#include <stdio.h>
#include <stdlib.h>


// Include the header for the function we want to call after we get
// the inputs from the user.

#include "process.h"

int main( int argc , char* argv[] ) {
    
	if (argc == 2) {
		processWord(argv[1]);
	}
  
	else {
		printf("This program echoes a word differently, depending on the word that is passed in. Usage:echoer [word]\n");
     
		return EXIT_FAILURE;
	}
	
   
	return EXIT_SUCCESS;
}
