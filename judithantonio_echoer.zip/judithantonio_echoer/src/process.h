//----------------------------------------------------------------------//
// Author:         Roman Lysecky, Ming Li
//                 (adpated from code by Jonathan Sprinkle)
// Net ID:         rlysecky
// Date:           06 January 2016
// Project Number: 0
// Project Name:   echoer
//
// Function prototype for processWord function
//----------------------------------------------------------------------//

#ifndef PROCESS_H
#define PROCESS_H

#include <stdlib.h>
#include <stdio.h>

void processWord(char *inputWord);

#endif // PROCESS_H