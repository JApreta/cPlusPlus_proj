Author: Judith Antonio

NetID: judithantonio
Date: 06 January 2016

Project Number: 


This program echoes a word differently, depending on the word that is passed in. Usage:

   echoer [word]

The inputted word should be echoed back to the terminal. If the word is Ping it should be echoed as the following with a newline at the end. 

   Give me a Ping. One Ping only, please.
