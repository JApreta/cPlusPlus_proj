/*
* File: Vehicle.h
* Author: judith antonio
* NetID: judithantonio
* Date:3/21/2016
*
* Description: Definition of the vehicle methods that 
allow the acces and mofitication of the vehicle state.
*/


#include <iostream>
using namespace std;
#include <cmath>
#include "State.h"
#include "Input.h"
#include "Vehicle.h"


Vehicle::Vehicle(){}//default constructor

void Vehicle::stateUpdate(Input u, double duration) {

	State x;
	double angle = 0.0, heading = 0.0, Ypos=0.0, Xpos=0.0, timeStamp=0.0;
	double angleRate = u.getTireAngleRate();//get the angke rate from the input class

	angle = this->_state.getTireAngle() + (duration*angleRate);//calculate the new angle value

	//*******************************Check if the angle value is valide*****************
	if (angle > MAX_TIRE_ANGLE_RATE)
		angle = MAX_TIRE_ANGLE_RATE;

	if (angle < MIN_TIRE_ANGLE_RATE)
		angle = MIN_TIRE_ANGLE_RATE;

 //****************************************************************************************

	heading = this->_state.getHeading()         //Calculate the new heading value
		    + (u.getVelocity()* duration
		    * sin(this->_state.getTireAngle()) / L);

//*******************************Check if the new  heading value is valide*****************

	if (heading < 0) {//if negative 
		while (heading < 0)
			heading = heading + M_TWO_TIMES_PI;//saturate by adding 2pi
	}

	if (heading >= M_TWO_TIMES_PI) {//if greater or equal than 2pi 
		while (heading >= M_TWO_TIMES_PI)
			heading = heading - M_TWO_TIMES_PI;//saturate by subtracting 2pi
	}
//****************************************************************************************
	

	Ypos = this->_state.getYPos() //calculate the new Yposition using the previous state data
		 + (u.getVelocity() 
		 * sin(this->_state.getHeading())
		 * cos(this->_state.getTireAngle())
		 * duration);

	Xpos = this->_state.getXPos() //calculate the new Xposition using the previous state data
		 + (u.getVelocity() 
		 * cos(this->_state.getTireAngle())
		 * cos(this->_state.getHeading())
		 * duration);

	timeStamp = this->_state.getTimeStamp() + duration;//calculate the new time using the previous state data

	
//update the vehicle state
	x.setHeading(heading);// set the new heading
	x.setTimeStamp(timeStamp);//set the new time
	x.setXPos(Xpos);//set the new xpos
	x.setYPos(Ypos);//set the new ypos
	x.setTireAngle(angle);//set the new angle

	this->setState(x);//set the new values for _state


}

Vehicle::Vehicle(State c ) {
	this->setState(c);
}//create a constructor with a gven state

void Vehicle::setState(State x)
{
	this->_state = x;
}//update the vehicle state



State Vehicle::getState() const
{
	return _state;
}//return the current _state of the vehicle
