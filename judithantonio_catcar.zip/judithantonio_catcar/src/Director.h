#ifndef DIRECTOR_H
#define DIRECTOR_H
/*************/
/*
* File: Director.h
* Author: judith antonio
* NetID: judithantonio
* Date:03/21/2016
*
* Description: Definition of the Director with method 
that coordinate the consumption of inputs, and save each output.
*/

#include "Input.h"
#include "State.h"
#include "Vehicle.h"
#include "DataSink.h"
#include <vector>


class Director {
private:

	Vehicle outState;
	//this object of the vehicle class is used to get the updatestate method from the vehicle class

public:

	void processVehicle(DataSink *Obj, vector <Input> inputs);
	//this  method  coordinate the consumption of inputs, and save each output
	
	Director(Vehicle x);//creates a director object with a vehicle data

};

#endif 