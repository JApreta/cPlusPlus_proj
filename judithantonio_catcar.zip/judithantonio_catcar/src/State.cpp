
/*************/
/*
 * File: State.h
 * Author: Your Name
 * NetID: Your NetID
 * Date:
 *
 * Description: (enter your description of what this file does).
 */

// M_PI and other variables are defined in here
#include <iostream>
using namespace std;
#include <cmath>
#include "State.h"
#include "Input.h"
#include "Vehicle.h"



	State::State(double x1, double x2, double x3, double x4, double timestamp) {
	
		this->_xpos = x1;
		this->_ypos = x2;
		this->_tire_angle = x3;
		this->_heading = x4;
		this->_timestamp = timestamp;
	
	
	}
    // constructs an empty State object
	State::State() {}

	double State :: getXPos() const{
		
		return(this->_xpos);
	} // returns the _xpos


	void State:: setXPos(double xpos) { 
		this->_xpos = xpos;
	
	} // sets the _xpos

	double State:: getYPos() const {

		return this->_ypos;
	}// returns the _ypos


	void State:: setYPos(double ypos) {

		this->_ypos = ypos;
	}// sets the _ypos


	double State:: getTireAngle() const {
	
		return this->_tire_angle;
	} // returns the _tire_angle


	void State:: setTireAngle(double angle) {

		this->_tire_angle = angle;

	}// sets the _tire_angle


	double State:: getHeading() const {
	
		return this->_heading;
	} // gets the _heading


	void State:: setHeading(double heading) {
	
		this->_heading = heading;
	} // sets the _heading


	double State:: getTimeStamp() const {
		return this->_timestamp;
	
	} // gets the _timestamp


	void State:: setTimeStamp(double timestamp) {
	
		this->_timestamp = timestamp;
	} // sets the _timestamp



