/*
* File: DataSource.cpp
* Author: judith antonio
* NetID: judithantonio
* Date:03/21/2016
*
* Description: Definition of of the methods that open the file and write the data of the file in a vector
sort the vector and validate it, and allo to acess the datafile from others classes
*/

#include <iostream>
using namespace std;
#include <cmath>
#include "Input.h"
#include "Vehicle.h"
#include "DataSource.h"
#include <string>
#include <fstream>
#include <sstream>
#include <vector>

DataSource::DataSource(){}//creates an empty DataSource object


//this function read the inputs from the file and put them in the vector of inputs
int DataSource::openFile(string Filename) {

	unsigned int i = 0;
	double time=0.0, vel= 0.0, angle= 0.0;
	istringstream inputLine;// to read from a string
	string line=" ";//to save each line from the file
	ifstream Inputfile;//to read from the file

	Inputfile.open(Filename.c_str());//try to open the file

	if (!Inputfile.is_open())//if not succeed
		return failOpenFile;
	

	if (Inputfile.peek() == ifstream::traits_type::eof()) {//check if the input file is empty

		Inputfile.close();//cloce the file
		return emptyFile;
	}

	while ( !Inputfile.eof() && getline(Inputfile, line).good()) {//run while it does not reach the end of file and doesn't fail to read a line
		

		//if(!line.empty()){//check if it is an empty line same as check if getline is good

			inputLine.str(line);//updated the stringstream with the line read from the file
		
			inputLine >> time;//read the time value from the sstrem
			inputLine >> vel;//read the velocity value from sstream
			inputLine >> angle;//read the angle value from the sstream

		this->dataFile.resize(i + 1);//resize the vector

		//******************************************************UPDATE THE VECTOR DATA******************************
		this->dataFile.at(i).setTimeStamp(time);
		this->dataFile.at(i).setVelocity(vel);
		this->dataFile.at(i).setTireAngleRate(angle);

		inputLine.clear();//clear the sstream to get an new line inn the next run
		i++;//update i
		//}
	}
	
	
	Inputfile.close();//close the file

	return openedFile;
}

//this method sort the vector of inputs in an ascending order using quicksort use the first elem of the vector or subvector as pivo
void DataSource:: quicksort(vector<Input>& toSort,  int low, int high) {
	unsigned int i = 0;
	 int j = 0;
	
	Input pivot( 
		toSort.at(low).getVelocity(),
		toSort.at(low).getTireAngleRate(),
		toSort.at(low).getTimeStamp() ); // get the pivot for each interaction the pivot is the first elem of the vector or subvector
	
	
	  i = low; // update i to check the elem from left to rigth
	 j = high; // update j to check the elem from rigth to left
	Input Swap;
	
	while (i <static_cast<unsigned int>( j) ){           //execute while i and j don't cross
		
		while (toSort.at(i).getTimeStamp() <= pivot.getTimeStamp() && i < toSort.size()-1)//check the elem on the left of the pivot are less than it
			i++; //move i to the rigth if doesn't reach the end of the vector

		while (toSort.at(j).getTimeStamp() > pivot.getTimeStamp())//check the elem on the rigth of the pivot are greater than it	
			j--;         //move j to the left

		if (i < static_cast<unsigned int>(j)) {//if they don't cross but the elem at the left is greater than the pivot
					// Swap them      
			Swap = toSort.at(i);
			toSort.at(i)=toSort.at(j);
			toSort.at(j)= Swap;

		}
	}
	// if i and j cross then
	toSort.at(low)=toSort.at(j); //update the elem in the low pos with the one on the current j
	toSort.at(j)= pivot; //update the elem in the j pos with the pivot at this point the pivot is in the rigth positin
	
	if (low < j-1 )//if the var that check the rigth side is on the left side of the pivot
		quicksort(toSort, low, j - 1); // sort the subvector on the left of the pivot from the low location until the elem befor the pivot
	
	if (j + 1 <high)//if the var that check the left side is on the rigth side of the pivot
		quicksort(toSort, j +1, high); //sort the subvector pn the rigth of the pivotfrom the elem after the pivot until the high location
	}


//This function call the quick sort function
void DataSource::sort()
{
	DataSource obj;
	//call tthe quicksort method passin the vector to be sorted, the position of the first elem and the size of the vector
	
	obj.quicksort(this->dataFile, 0, (this->dataFile.size() - 1));

}


//This function check all the condition to validate an input file
bool  DataSource::validate() {
	unsigned int i = 0;
	int check = 0;
	double duration = 0.0;
	

	if(this->dataFile.at(0).getTimeStamp() > 0.0 )//check if the first elem has time=0
		return false;

	for (i = 0; i < this->dataFile.size(); i++) {

		if(i<this->dataFile.size()-1)//calculate the duration of all elem in the vector
		duration = this->dataFile.at(i + 1).getTimeStamp() - this->dataFile.at(i).getTimeStamp();

		if (this->dataFile.at(i).getTimeStamp() < 0.0){//check if the time is negative
			check++;
			break;
		}

		if (this->dataFile.at(i).getTireAngleRate() > MAX_TIRE_ANGLE_RATE || this->dataFile.at(i).getTireAngleRate() < MIN_TIRE_ANGLE_RATE)
		{// check if there is an elem with angle out of range
			check++;
			break;
		}

		if(this->dataFile.at(i).getVelocity() < 0.0 || this->dataFile.at(i).getVelocity() > 30)
		{//check the bounderies of the velocity for all elements
			check++;
			break;
		}	

		if(duration < 0.005 || duration > 0.201) {//check if the durantion is out of range
			check++;
			break;
		}
	
	}

	if (check == 0)//if all conditions are OK
		return true;
	else//if not
		return false;

}

//this function returns the vector with all the inputs sorted 
vector <Input> DataSource::getdataFile()const
{
	return dataFile;
}

//this function return the size of the vector input
int DataSource::dataFileSize()
{
	return this->dataFile.size();;
}


