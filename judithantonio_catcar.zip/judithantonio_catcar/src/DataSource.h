#ifndef DATASOURCE_H
#define DATASOURCE_H
/*************/
/*
* File: DataSource.h
* Author: judith antonio
* NetID: judithantonio
* Date:03/21/2016
*
* Description: Definition of DataSource class. this class contains declaration of function to get 
				the data from the file
			    the private vector from this class,
				the size of the vector,
				to sort the vector data and to validate it
*/

#include "Input.h"
#include <vector>
#include<string>


class DataSource {
private:
	vector <Input> dataFile;//this vactoe holds the data from the input file
	
public:
	
	DataSource();//construct an empty datasource object
	vector <Input> getdataFile()const;//return the input vector
	int openFile(string Filename);//open the file and paste the datafile to the vector
	int dataFileSize();//return the input vector size
	void quicksort(vector<Input>& toSort, int first_index, int last_index);//perform a quicksort on the input vector
	bool validate();//validate the data
	void sort();//call the quicksort data
	
};

#endif 
