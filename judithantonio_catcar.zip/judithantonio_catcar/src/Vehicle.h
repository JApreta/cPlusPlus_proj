#ifndef VEHICLE_H
#define VEHICLE_H
/*************/
/*
 * File: Vehicle.h
 * Author: judith antonio
* NetID: judithantonio
* Date:03/21/2016
 *
 * Description: definition of the Vehicle class.
 */

#include "State.h"
#include "Input.h"

// wheelbase length in meters
#define L 2.6187
#define failOpenFile 1
#define openedFile 0
#define emptyFile 2


/**************************************************************************************
Declaration of the methods that update the state of the vehicle
creates an empty object and an vehilce object with a state data
allow accessof  the _state var outside of the class to
*****************************************************************************************/

class Vehicle {
private:
    State _state; // the current state of the vehicle
    void setState(State x); // sets the value for _state
    
public:
    // constructs a new Vehicle object with the default State value
    Vehicle();
    // executes the Vehicle for the duration specified
    // this method does not do any correctness checking on values in u
    void stateUpdate( Input u, double duration );

	Vehicle(State c);
    
    State getState() const; // gets the value for _state
};

#endif // VEHICLE_H
