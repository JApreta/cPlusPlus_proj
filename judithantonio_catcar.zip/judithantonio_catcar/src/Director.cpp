/*
* File: Director.cpp
* Author: judith antonio
* NetID: judithantonio
* Date:03/21/2016
	*
	* Description : definition of the Director's methods, 
	this file show in detail how the dirctor coordenate the vehicle consumption using the processVehicle method
	*/


#include <iostream>
using namespace std;

#include <vector>
#include "Input.h"
#include "Vehicle.h"
#include "DataSource.h"
#include "DataSink.h"
#include "Director.h"

Director::Director(Vehicle x)
{
	this->outState = x;//initialize the outState member
}

/**********************************************************************************************
this method coordinate the consumption of inputs, and save each output. 
for ecah imput from the datafile vector of the datasource class
update the vehicle state and save it in the outState vector of the datasink class
***********************************************************************************************/
void Director::processVehicle(DataSink *Obj, vector <Input> inputs)
{
	unsigned int i = 0 ; 
	double duration = 0.0;

	for (i = 0; i < inputs.size(); i++) {//for all inputs
	
		if (i < inputs.size() - 1)//before the last element
			//calculate the duration from one element to another
			duration = inputs.at(i+1).getTimeStamp() - inputs.at(i).getTimeStamp();
			
		else//for the last elem
			duration = 0.2;//use 200ms for duration

		this->outState.stateUpdate(inputs.at(i), duration);
		//update the vehicle state with each input and the corresponding  duration by calling the stateUpdate method from the vehicle class

		(*Obj).setStateOutput(this->outState.getState(), i);
		//write the update states in to the outputfile	by calling the setStateOutput from the datasink class    
		
	}
}



