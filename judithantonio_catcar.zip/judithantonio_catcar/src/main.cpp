/*
* File: main.cpp
* Author: judith antonio
* NetID: judithantonio
* Date:3/8/2016
*
* Description: thsi file holds the main function which execute the methods of others classes as need.
*/


#include <iostream>
using namespace std;
#include <cmath>
#include "State.h"
#include "Input.h"
#include "Vehicle.h"
#include "DataSource.h"
#include "DataSink.h"
#include "Director.h"

int main(int argc, char *argv[]) {

	int inputFile = 0, outputFile = 0; 
	bool valide=false;


	//creates and intialize all classes objects as needed

	DataSource datasourceObj;//creats an empty datasource object
	State stateObj(0.0, 0.0, 0.0, 0.0, 0.0);//creates an object of the state class setting all var element to zero
	Vehicle vehicleObj(stateObj);//creates an vehicke object using the previoud state object
	DataSink datasinkObj;//creates an empty datasink object
	Director directorObj(vehicleObj);//creates a director object using the previous vehicle object

	if (argc != 3){//check the argument #
		cout << "Usage: catcar controlInputs stateOutputs"<<endl;
		return 1;
	}
	
	inputFile = datasourceObj.openFile(argv[1]);//try to open the input file from the datasource class

	if (inputFile == failOpenFile){//check if opened successfuly
		cout << " Could not read ControlInput file "<< argv[1]<<endl;
		return 1;
	}

	if (inputFile == emptyFile) {//check if the input file is empty if so

		outputFile = datasinkObj.CreateEmptyFile(argv[2]);// try to create an empty output file
		
		if (outputFile != 0) {//check if succeed
			cout << " Could not create empty OutputState file " << argv[2] << endl;

		}
		return 1;
	}

	datasourceObj.sort();//sort the the vector
	valide = datasourceObj.validate();//valitade it

	if (valide == false ) {// if the input data aren't valide
		
		outputFile = datasinkObj.CreateEmptyFile(argv[2]);// try to create an empty output file
		
		if (outputFile != 0) {//check if succeed
			cout << " Could not create empty OutputState file " << argv[2] << endl;
			
			return 1;
		}
	}

	else {//if the imutd are valid
		

		datasinkObj.resizeStateOutput(datasourceObj.dataFileSize());//resize the output vector to have the same size as the valid input vector

	    directorObj.processVehicle(&datasinkObj, datasourceObj.getdataFile());
		//call the process vehicle from the director passing as argument the adrees of the datasinkObj and the input vector from the datasorce class
        //used the address to modity the contant of the output vector in the director class

		outputFile = datasinkObj.openOutputFile(argv[2]);
		//try to open and write the output state data in the outputfile

			if (outputFile == failOpenFile) {//check if succeed
				cout << " Could not creaete OutputState file " << argv[2] << endl;
				
				return 1;
			}

	}
	return 1;
}