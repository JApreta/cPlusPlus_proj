/*
* File: DataSink.cpp
* Author: judith antonio
* NetID: judithantonio
* Date:03/21/2016
*
* Description: (enter your description of what this file does).
*/


#include <iostream>
using namespace std;
#include <cmath>
#include "State.h"
#include "Input.h"
#include "Vehicle.h"
#include "DataSource.h"
#include <fstream>
#include <sstream>

#include "DataSink.h"

DataSink::DataSink()
{
}


void DataSink::resizeStateOutput(int size)
{
	this->stateOutput.resize(size);
}

void DataSink::setStateOutput(State outSate, int index)
{
	
	this->stateOutput.at(index).setTimeStamp(outSate.getTimeStamp());
	this->stateOutput.at(index).setHeading(outSate.getHeading());
	this->stateOutput.at(index).setTireAngle(outSate.getTireAngle());
	this->stateOutput.at(index).setXPos(outSate.getXPos());
	this->stateOutput.at(index).setYPos(outSate.getYPos());

}

vector <State> DataSink::getStateOutput() const
{
	return stateOutput;
}

int DataSink::openOutputFile(string Filename)
{
	unsigned int i=0;
	
	ofstream Outputfile;
	Outputfile.open(Filename.c_str());

	if (!Outputfile.is_open())
		return failOpenFile;

	else {
		
		for (i = 0; i < this->stateOutput.size(); i++){
			Outputfile 
			<< this->stateOutput.at(i).getTimeStamp() << ","
			<< this->stateOutput.at(i).getXPos() << ","
			<< this->stateOutput.at(i).getYPos() << ","
			<< this->stateOutput.at(i).getTireAngle() << ","
			<< this->stateOutput.at(i).getHeading() << endl;
			
		}

	}
	Outputfile.close();
	return openedFile;
}

int DataSink::CreateEmptyFile(string Filename)
{
	ofstream Emptyfile;
	Emptyfile.open(Filename.c_str());

	if (Emptyfile.is_open()){
		Emptyfile.close();		
		return openedFile;
	}
	else
		return failOpenFile;
}
