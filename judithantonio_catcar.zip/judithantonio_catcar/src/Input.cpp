
/*
 * File: Input.cpp
 * Author: judith antonio
 * NetID: judithantonio
 * Date:03/21/2016
 *
 * Description: this file contains the definiton of the methods responsable for acces and modify the content an element of the input class.
 */



// M_PI and other variables are defined in here
#include <iostream>
using namespace std;
#include "Input.h"

	Input::Input(double vel, double tireAngleRate, double timestamp) {
     //the constructor initialize the private var with the given parameters
		this->_velocity = vel;
		this->_tire_angle_rate = tireAngleRate;
		this->_timestamp = timestamp;
	
	}   //construct an object with the given parameters
   
	Input::Input() {} // constructs an empty Input object

	double Input::getVelocity() const {
	
		return this->_velocity;
	} // returns the _velocity


	void Input::setVelocity(double vel) {
		this->_velocity = vel;
	
	}// sets the _velocity


	double Input::getTireAngleRate() const {
	
		return this->_tire_angle_rate;
	} // returns the _tire_angle_rate


	void Input::setTireAngleRate(double angle) {
	
		this->_tire_angle_rate = angle;
	
	} // sets the _tire_angle_rate

	double Input::getTimeStamp() const {
	
		return this->_timestamp;
	} // gets the _timestamp


	void  Input::setTimeStamp(double timestamp) {
	
		this->_timestamp = timestamp;
	
	} // sets the _timestamp
