#ifndef DATASINK_H
#define DATASINK_H
/*************/
/*
* File: DataSink.h
* Author: judith antonio
* NetID: judithantonio
* Date:03/21/2016
*
* Description: definition of the datasink class with declaration of methods that
resize the vector and change its data from outside of the class
retun the output vector, creates an empty file,paste the vector data into a file

*/

#include "State.h"
#include <vector>

class DataSink {
private:
	
	vector <State> stateOutput;//this vector holds the update vehicle data state

public:
	
	DataSink();// construct an empty datasink object
	
	void resizeStateOutput(int size);//this method allows to resize the output vector outside the class
	void setStateOutput(State outSate,int index);//this method saves the new state in the vector
	vector <State> getStateOutput() const;//returns the output vector
	int openOutputFile(string Filename);//open and paste the vector data into the output file
	int CreateEmptyFile(string Filename);//creates an empty file
	
	
};

#endif 
