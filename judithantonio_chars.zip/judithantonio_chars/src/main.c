//----------------------------------------------------------------------//
// Author:         Judith Antonio
// Net ID:         judithantonio
// Date:           01 march 2016
// Project Number: 2
// Project Name:   chars
//
// Contains the main function.
//----------------------------------------------------------------------//
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "dlist.h"
#include "stringprocessing.h"

// Include the header for the function we want to call after we get
// the inputs from the user.


int main(int argc, char *argv[]) {

	int CardFile = 0,StringFile=0, outputFile=0;
	DList  Unprocessed_cards, Unprocessed_strings, Processed_cards;

	if (argc != 4) {//check the number of arguments

		printf("Usage: chars inputCardsFile inputStringsFile outputFile");
			return EXIT_SUCCESS;
	}
    
	
	DListConstruct(&Unprocessed_cards);   //create the Unprocessed_cards list
	DListConstruct(&Unprocessed_strings);//create the Unprocessed_string list
	DListConstruct(&Processed_cards);   // create the  Processed_cards list


	//***************************Try open the imputCard file and check if it exist*************************
	CardFile = ReadCardFromFile(&Unprocessed_cards,argv[1]);

	if (CardFile == -1) {
		printf("Could not read Card file %s\n", argv[1]);

		return EXIT_FAILURE;
	}
//**********************************************************************************************************

//***************************Try open the imputString file and check if it exist*************************
	StringFile=ReadStringFromFile(&Unprocessed_strings, argv[2]);

	if (StringFile == -1) {
		printf("Could not read Card file %s\n", argv[2]);

		return EXIT_FAILURE;
	}
//**********************************************************************************************************

	FillBlankCards(&Unprocessed_cards, &Unprocessed_strings, &Processed_cards);

	//***************************Try open the outputFile check if it exist and write the results on it*************************
	outputFile = WriteCardsResultsToFile(&Processed_cards, argv[3]);

	if (outputFile == -1) {
		printf("Could not read Card file %s\n", argv[3]);

		return EXIT_FAILURE;
	}
//******************************************************************************************************************************
	
	//destruct the tree lists
	DListDestruct(&Unprocessed_cards);
	DListDestruct(&Unprocessed_strings);
	DListDestruct(&Processed_cards);

   
	return EXIT_SUCCESS;
}
