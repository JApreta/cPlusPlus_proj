/**************************************************************************************************/

/*
 * File: sporkprofile.h
 * Author:judith antonio
 * NetID: judithantonio
 * Date:3/1/2016
 *
 * Description: Definition of SporkProfile for storing profile data for a restauarant/business
 *              declaration of functions for reading, processing, and writing Spork profiles.
 *
 */

/**************************************************************************************************/

#ifndef STRINGPROCESSING_H
#define STRINGPROCESSING_H

/**************************************************************************************************/
#include "dlist.h"


DListNode *Newlistnode(char newString[]);//create a node for the string list and initialize all elements

int ReadStringFromFile(DList *stringlist,char *fileName);//read the string from the file, and the created node on the list of strings


#endif

/**************************************************************************************************/
