/**************************************************************************************************/

/*
 * File: sporkprofile.h
 * Author:judith antonio
 * NetID: judithantonio
 * Date:03/1/2016
 *
 * Description: Definition of SporkProfile for storing profile data for a restauarant/business
 *              declaration of functions for reading, processing, and writing Spork profiles.
 *
 */

/**************************************************************************************************/

#ifndef OUTPUT_H
#define OUTPUT_H

/**************************************************************************************************/

#include "dlist.h"

int  WriteCardsResultsToFile(DList * Processed_cards, char *fileName);
#endif

/**************************************************************************************************/
