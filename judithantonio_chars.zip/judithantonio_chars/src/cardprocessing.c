/**************************************************************************************************/

/*
 * File: cardprocessing.c
 * Author:judith Antonio
 * NetID:judithantonio
 * Date:3/1/2016
 *
 * Description: Function definitions for reading and check valid cards from athe file
 Create a node for the unprocessed cardList 
 Fill the blank of a card (process a card)and
 , Add a processedcard on the processedCard List
 
 *
 */

/**************************************************************************************************/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
#include "dlist.h"
#include "stringprocessing.h"

/**************************************************************************************
Create a node for the unprocessed cardList 
with the repective information about the blank size and first index
****************************************************************************************/

DListNode *NewCardnode(char newString[], int blankIndex, int blankLength) {//recebe a string
	
	 DListNode * newNode = (DListNode *)malloc(sizeof(DListNode));//allocate the newnode

	newNode->next = NULL;//set the next point to null
	newNode->prev = NULL;//set the prev to null

	newNode->blankIndex = blankIndex;//save the index of the first blank
	newNode->blankLength = blankLength;//save the length of the blank

	newNode->str = (char *)malloc((strlen(newString)+1)*sizeof(char));//allocate the string array
	strcpy( newNode->str,newString);//updated the card data with the string

	newNode->cardSize = strlen(newNode->str);//save the card size

	return newNode;
}


/***************************************************************************************************
Add the new node on the processedCard List on its apropiated place based on the card length
****************************************************************************************************/

void CreateProcessedCardsList(DListNode *NewCard, DList *ProcessedCard) {
	
	DListNode * currNode = NULL;
	
	if(ProcessedCard->head==NULL)//if the list is empty
		DListInsertBefore(ProcessedCard,NULL, NewCard);//add the newcard on the head and tail

	else if(NewCard->cardSize >= ProcessedCard->tail->cardSize)//if the size of newcard is greater than the tail size
			DListInsertAfter(ProcessedCard, ProcessedCard->tail, NewCard);//update the tail with the newcard

	else if (NewCard->cardSize <= ProcessedCard->head->cardSize)//if the size of the newcard is less than head size 
		DListInsertBefore(ProcessedCard, ProcessedCard->head, NewCard);//updated the head with the new card

	else {//look to insert thenewcard some where in the middle of the list

		currNode = ProcessedCard->head;//currnode get the head of the list

		while(NewCard->cardSize >= currNode->cardSize) {//percorre alist until find a card with greater size than the newnode
			currNode = currNode->next;
			}
		DListInsertBefore(ProcessedCard, currNode, NewCard);//when found put the new node before the currnode
		}
	}


/* ********************************************************************************************
Open the card file read each card and check if has the valid requirement for blankspace 
Call the newnode function to create anode with the card information
and add the newnode na lista de unprocessedCards
***********************************************************************************************/

int ReadCardFromFile(DList *UnprocessedCards, char *fileName) {
	
	char processCard[MAX_STINGLENGTH];
	int i = 0, index = 0, blankLen = 0;
	DListNode  *newNode = NULL, *currNode = NULL;
	FILE * Cardinp = NULL;
	
	Cardinp = fopen(fileName, "r");//try open the file

	if (Cardinp == NULL)//if does not exist
		return -1;
	
	while (fgets(processCard, MAX_STINGLENGTH, Cardinp)!=NULL) {//execute if does not reaxh the end of file

		//;//get the cards line by line
		
		if(processCard[strlen(processCard) - 1]=='\n')//if the string ends with a new line
			processCard[strlen(processCard)-1] = '\0';//replace it with the null char
		
		for (i = 0; i < strlen(processCard); i++) {//for the entire string look for a blank space

			if(processCard[i] == '_') {// if found 
				index = i;             //save the index of the first one
				break;
				}		
			}

		while (processCard[i] == '_') {//while there is a blank space
			blankLen++;                //count it
			i++;                      	
			}

			if (blankLen >= 3) {// if the blank is greater or equal 3

				newNode = NewCardnode(processCard, index, blankLen);//create a new node for the unprocessedCard list
				DListInsertAfter(UnprocessedCards, currNode, newNode);//and add it to the lis
				currNode = newNode;//update currNode		
			}
			
			blankLen = 0;//reset blankLen for the new card	
	}
	
	return 0;
}

/***********************************************************************************************
Call the search function to look for a match in the stringList
if found it create anwe node for the procesedCard list fill the blank with the respactive string
and Add the newNode on the list
**************************************************************************************************/
void FillBlankCards(DList *UnprocessedCards, DList *UnprocessdString, DList *processedCard){

	if (UnprocessedCards == NULL || UnprocessdString == NULL || processedCard == NULL)
		return;

	int i;
	DListNode *CurrUnprocard = UnprocessedCards->head,//var that gets the current unprocessedcard
			  *StringList = NULL,                    //var that gets the match string
		      *NewproCard=NULL;                     //var that gets the new node for thr processcardlist
	
	
	while (CurrUnprocard != NULL) {//run until reach the end of the unprocessed card list

		//call the serach function to look for a string with the same length as the blank
		StringList = DListSearch(UnprocessdString, CurrUnprocard->blankLength);

		
		if(StringList!=NULL){//if there is a match

							 //create a new node for the processcard list with the same format as the the stringList
			NewproCard = Newlistnode(CurrUnprocard->str);

			for (i = 0; i < CurrUnprocard->blankLength; i++)
				 NewproCard->str[CurrUnprocard->blankIndex++] = StringList->str[i];//Fill the blank in the new node
				
			CreateProcessedCardsList(NewproCard, processedCard);//add the new node on the ProcesscardList
		    DListRemove(UnprocessdString,StringList);//remove the macth string from the Stringlist

			}
		CurrUnprocard = CurrUnprocard->next;//got to the next unprocessed card
		
	}
	return;
}
