/**************************************************************************************************/

/*
 * File: cardprocessing.h
 * Author:judith antonio
 * NetID: judithantonio
 * Date:03/01/2016
 *
 * Description: Definition of cardprocessing 
 *              declaration of functions for reading a card, processing a card, and create anode.
 *
 */

/**************************************************************************************************/

#ifndef CARDPROCESSING_H
#define CARDPROCESSING_H

/**************************************************************************************************/

#include "dlist.h"

/**************************************************************************************************/

/**************************************************************************************
Create a node for the unprocessed cardList
with the repective information about the blank size and first index
****************************************************************************************/
DListNode *NewCardnode(char * newString,int blankIndex,int blankLength);//recebe a string

/***************************************************************************************************
Add the new node on the processedCard List on its apropiated place based on the card length
****************************************************************************************************/

void CreateProcessedCardsList(DListNode *NewCard, DList *list);//verify if the lengh of string e choose between insert after or before


/* ********************************************************************************************
Open the card file read each card and check if has the valid requirement for blankspace 
Call the newnode function to create anode with the card information
and add the newnode na lista de unprocessedCards
***********************************************************************************************/
int ReadCardFromFile(DList *UnprocessedCards, char *fileName);//tira do file e check if it is valid(tem o required blank) chama a NewCardnode e o FILL passando o new node


/***********************************************************************************************
Call the search function to look for a match in the stringList
if found it create anwe node for the procesedCard list fill the blank with the respactive string
and Add the newNode on the list
**************************************************************************************************/
void FillBlankCards(DList *UnprocessedCards, DList *Unstring, DList *UprocessedCard);//procura a match na string list, remove o match


#endif

/**************************************************************************************************/
