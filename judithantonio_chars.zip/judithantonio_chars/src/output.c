/**************************************************************************************************/

/*
 * File: output.c
 * Author:judith Antonio
 * NetID:judithantonio
 * Date:3/1/2016
 *
 * Description: Function definitions for  writing process Cards in the output file.
 *
 */

/**************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "dlist.h"
#include "stringprocessing.h"

/****************************************************************************
write the processcard from the processcardlist into the output file
***************************************************************************/
int  WriteCardsResultsToFile(DList * Processed_cards, char *fileName){

	DListNode *currNode = Processed_cards->head;
	FILE * CardsFileout = NULL;

	CardsFileout = fopen(fileName, "w+");//try open the file

	if (CardsFileout == NULL)//if does not exist
	return -1;

	while (currNode != NULL) {//execute while does't reach the end of the list

		fprintf(CardsFileout, "%s\n", currNode->str);//write current node data in the file

		currNode = currNode->next;//update current Node
	}
return 0;

}