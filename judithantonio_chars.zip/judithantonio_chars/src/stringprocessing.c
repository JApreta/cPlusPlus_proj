/**************************************************************************************************/

/*
 * File: stringprocessing.c
 * Author:judith Antonio
 * NetID:judithantonio
 * Date:3/1/2016
 *
 * Description: Function definitions for reading the imput string from the file and add items on the string list.
 *
 */

/**************************************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "dlist.h"
#include "stringprocessing.h"

/****************************************************************************
Create a new Node for the string List and initialize all the elements
*****************************************************************************/
DListNode *Newlistnode(char newString[]) {

	 DListNode * newNode = (DListNode *)malloc(sizeof(DListNode));//allocate the new node

	newNode->next = NULL;//set nextpointer to null
	newNode->prev = NULL;//set prevpointer to null

	newNode->blankIndex = -1;//set blank index to -1
	newNode->blankLength = -1;//set blank lenght -1

	newNode->str = (char *)malloc((strlen(newString) + 1)*sizeof(char));//allocate the string array

	strcpy(newNode->str, newString);//add the content of the string
	newNode->cardSize =strlen(newString) ;//save the string length
	
	return newNode;
}

/*******************************************************************************************
Read the string from the imput file, call the create node function and 
add the new node on the list of strings
**********************************************************************************************/

int ReadStringFromFile(DList *stringlist, char *fileName) {

	DListNode *currNode = NULL,*newNode=NULL;
	FILE * Stringinp = NULL;
	char processString[MAX_STINGLENGTH];
	

	Stringinp = fopen(fileName, "r");//try open the file

	if (Stringinp == NULL)//if does not exist
		return -1;

	while (fscanf(Stringinp, "%s", processString)!=EOF) {//execute if does not reaxh the 

		//;//get the strings line by line

		if (strlen(processString)>=3) {//check the size of the string


			newNode = Newlistnode(processString);//create a new node
			DListInsertAfter(stringlist, currNode, newNode);//Add new node on the list
			currNode = newNode;//update current node

		}
		
	}

	return 0;
}

/**************************************************************************************************/
