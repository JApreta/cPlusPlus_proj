/*******************************************************************************************/

/*
 * File: dlist.h
 * Author: judith Antonio
 * NetID: judithantonio
 * Date:2/22/2016
 *
 * Description: struct definitions for the nodes and list and function declaration to create or implement adouble linked list
 *
 */

/*******************************************************************************************/


/*******************************************************************************************/

#ifndef DLIST_H
#define DLIST_H

/*******************************************************************************************/

/* if the str does not contain a blank, then blankIndex and blankLength should be -1 */
typedef struct DListNode_struct {//struc for each one of the listt
	
   char *str;
   int blankIndex;
   int blankLength;
   int cardSize;
   struct DListNode_struct *next;
   struct DListNode_struct *prev;
} DListNode;

typedef struct DList_struct {//struct for the list
   int size;
   DListNode *head;
   DListNode *tail;
} DList;

#define MAX_STINGLENGTH 1024

/*******************************************************************************************/

/* creates a new list and initializes the head/tail */
void DListConstruct(DList* list);

/* removes all items from the list, deallocating each item */
void DListDestruct(DList* list);

/* inserts newNode after the given currNode */
void DListInsertAfter(DList* list, DListNode* currNode, DListNode* newNode);

/* inserts newNode before the given currNode */
void DListInsertBefore(DList* list, DListNode* currNode, DListNode* newNode);

/* return the first list node to match key */
DListNode* DListSearch(DList* list, int key);

/* remove the list node (if it is a member of the list) */
void DListRemove(DList* list, DListNode* currNode);

/*******************************************************************************************/

#endif // DLIST_H