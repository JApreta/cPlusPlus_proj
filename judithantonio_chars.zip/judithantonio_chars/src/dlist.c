/*******************************************************************************************/

/*
 * File: dlist.c
 * Author: Judith Antonio
 * NetID:  judithantonio
 * Date:  02/22/2016
 *
 * Description: Function definitions for create a list, destruct a list, remove an element of the list
 * search an elemnt on the list and insert elements on the list in a specific place
 *
 */

/*******************************************************************************************/

/* Note: comments in this file thus far are insufficient for a perfect grade in comments */

/*******************************************************************************************/

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "dlist.h"

/*******************************************************************************************/

/* creates a new list and initializes the head/tail */

void DListConstruct(DList* list) {
	 
	list->head = NULL;//set the head to null
	list->tail = NULL;//set the atai to null
	list->size = 0;//set the size to zero 
   
}

/*******************************************************************************************/

/* removes all items from the list, deallocating each item from tail to the head */

void DListDestruct(DList* list) {


	if (list->head == NULL || list==NULL)//check if the lis exist or if it is empty
		return ;

	else{
	DListNode *nextNode= list->tail,*currNode = list->tail;

	while(nextNode != list->head){//run unitl reach the head of the list
		
		currNode->prev->next = NULL;//update the next of the previos node to null
		list->tail = currNode->prev;//update the tail

		free(currNode->str);//free the array of string
		free(currNode);//free the node

		currNode = list->tail;//update the current node
		nextNode = list->tail;//update the next node
		
		list->size--;//decrement the list size
	}

	//remove the head
	list->head = NULL;
	list->tail = NULL;
	list->size = 0;//set list size to zero

	free(currNode->str);//free the array of string
	free(currNode);//free the node

	}
}

/*******************************************************************************************/

/* inserts newNode after the given currNode */

void DListInsertAfter(DList* list, DListNode* currNode, DListNode* newNode) {

	if (list == NULL)//check if the list exist
		return;

	if (list->head == NULL) {//if the list is empty
		list->head = newNode;//update haed 
		list->tail = newNode;//and tail
	}
		
	else if (currNode == list->tail) {//if the current node is the tail

		newNode->prev = currNode;//newNde previous point to currentnode
		currNode->next = newNode;//update cuurnode next with newnode
		list->tail = newNode;//update tail with new node
	}
	
	else{//if we wish to insert between two elements

	newNode->next = currNode->next;//newNde next point to currentnode point next
	newNode->prev = currNode;//newNde previous point to currentnode
	(currNode->next)->prev = newNode; // update the currnode prev point with new node
	currNode->next = newNode;//update the currnode next point with new node
	
	}
	list->size++;//increment the list size
}

/*******************************************************************************************/

/* inserts newNode before the given currNode */

void DListInsertBefore(DList* list, DListNode* currNode, DListNode* newNode) {

	if (list == NULL)//check if the list exist
		return;

	if (list->head == NULL) {//if the list is empty
		list->head = newNode;//update haed 
		list->tail = newNode;//and tail
	}

	else if (currNode == list->head) {//if the newnode is the head

		newNode->next = currNode;//newNde next point to currentnode
		currNode->prev = newNode;//update cuurnode prev with newnode
		list->head = newNode;//update head with new node
	}

	else {

		newNode->prev = currNode->prev;//update newNde prev point to currentnode point prev
		newNode->next = currNode;//update newNde next point to currentnode
		currNode->prev->next = newNode;// update the next point of the currnode prev nde with new node
		currNode->prev = newNode;//update the currnode prev point with new node
		
	}
	list->size++;//increment the list size
   
}

/*******************************************************************************************/

/* return the first list node to match key */

DListNode* DListSearch(DList* list, int key) {

	DListNode* currNode = list->head;

	while (currNode != NULL) {
		if ((strlen(currNode->str)) == key)//check if the string has the same size as the blank
		
			break;//if found stop the search
		currNode = currNode->next;//go to the next node of the list
	}

   return currNode;
}

/*******************************************************************************************/

/* remove the list node (if it is a member of the list) */

void DListRemove(DList* list, DListNode* currNode) {

	if (list->head == NULL || list==NULL)//if the list is empty or doesn't exist
		return ;

	if (list->size == 1) {//if there is one element on the list
					//set head and tail to null
		list->head = NULL;
		list->tail = NULL;
	
		}

		else if (currNode == list->head) {//if what to remove the head

			list->head = currNode->next;//update the head with the next node of the list
			currNode->next->prev = NULL;//set null on the prev of the new head
			
		}
		else if (currNode == list->tail) {//if what to remove the tail

			list->tail = currNode->prev;//update the tail with the prev node of the tail
			currNode->prev->next = NULL;//set null on the next point of the new tail
			
		}

		else{//if wnat to remove somewhere in between
			currNode->prev->next = currNode->next;// update the next ofprevios node with the next of the one u want to remove
			currNode->next->prev = currNode->prev;// update the previos of the next node with the prev node of the one u want to remove
			
	}
		free(currNode->str);//free the array of string
		free(currNode);//free the node
		list->size--;//decrement the size
   
}

/*******************************************************************************************/
