//------------------------------------------------------------------------------------------------
//
// File: user.h
//  Author: judithantonio
// Date: April 26, 2016
//* NetID : judithantonio
// Description: definition of the user class with some costum.. constructors and get and set function to access and modify the member var
//
//------------------------------------------------------------------------------------------------

#ifndef User_H
#define User_H

#include <vector>
#include <string>
#include "edge.h"
using namespace std;

class User {
private:

	string userName;//save the username
	Edge* adjacentList;//object o acess and creat the adjcent list with the users being followed
	
	int inDegreeofCentrality;//save the indegree of centrality of each node
	int outDegreeofCentrality;//save the outdegree of centrality of each node
	
public:

	User(string userName);//creates an object with the given user name
	User();//default constructor
	User(Edge* adjacentList, string userName);//creates an object with a given username and a ointer o the edge object
   string getuserName()const;//return the username
   int getinDegreeofCentrality()const;//return the indegree of centrality
   int getoutDegreeofCentrality()const;//return the out degree of centrality
   Edge* getadjacentList()const;//return a pointer to the edge obj
   void IncrementinDegreeofCentrality();//increment the indegree of centrality
   void IncrementoutDegreeofCentrality();//increment the outdegree of centrality
   void setinDegreeofCentrality(int X);//update the indegree of centrality witha given value
   void setoutDegreeofCentrality(int X);//update the outdegree of centrality witha given value
 
};

#endif

//------------------------------------------------------------------------------------------------


