#include "user.h"
#include "edge.h"

//------------------------------------------------------------------------------------------------
//
// File: user.cpp
//  Author: judithantonio
// Date: April 26, 2016
//* NetID : judithantonio
// Description:This file cointans the definition of all the user class members
//
//------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------------------------

//costum.. constructor 1
User::User(string userName)
{
	this->userName = userName;
	this->adjacentList = adjacentList;
	this->inDegreeofCentrality = 0;
	this->outDegreeofCentrality = 0;
}

//default constructor
User::User()
{
}

//costum.. constructor 2
User::User(Edge * adjacentList, string userName)
{
	this->userName = userName;
	this->adjacentList = adjacentList;
	this->inDegreeofCentrality = 0;
	this->outDegreeofCentrality = 0;
}

// this method allow access to username outside of the class
string User::getuserName() const
{
	return this->userName;//return the username
}

// this method allow access to the indegree of centrality outside of the class
int User::getinDegreeofCentrality() const
{
	return inDegreeofCentrality;//return the indegreeof central
}

// this method allow access to the outdegree of centrality outside of the class
int User::getoutDegreeofCentrality() const
{
	return outDegreeofCentrality;// return the outdegree of central
}

// this method allow access to the edge obj outside of the class
Edge* User::getadjacentList() const
{
	return this->adjacentList;//retun a pointer to the edge obj
}

//this method increment the in degree of centrality 
void User::IncrementinDegreeofCentrality()
{
	this->inDegreeofCentrality++;
}

//this method increment the outdegree of centrality 
void User::IncrementoutDegreeofCentrality()
{
	this->outDegreeofCentrality++;
}

//this method update the indegree of centrality witha given value
void User::setinDegreeofCentrality(int X)
{
	this->inDegreeofCentrality = X;
}

//this method update the outdegree of centrality witha given value
void User::setoutDegreeofCentrality(int X)
{
	this->outDegreeofCentrality = X;
}





