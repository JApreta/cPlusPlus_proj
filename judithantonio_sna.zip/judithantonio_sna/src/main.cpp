/*
* File: main.cpp
* Author : judith antonio
* NetID : judithantonio
* Date : 4 /26/2016
*
* Description : thsi file holds the main function which execute the methods of others classes as need.
*/

//------------------------------------------------------------------------------------------------


#include <iostream>
#include <algorithm> 
#include "edge.h"
#include "user.h"
#include "graph.h"

using namespace std;


int main(int argc, char *argv[]) {

	int inputFile = 0, outputFile = 0;
	Graph Graph_obj;

	vector<User> SuggestedUsers_toFollow;

	if (argc != 4) {//check the argument #
		cout << "Usage: sna inputFile userName outputFile" << endl;
		return 1;
	}

	inputFile = Graph_obj.openFile(argv[1]);//try to open the input file

	if (inputFile == failOpenFile) {//check if opened successfuly
		cout << " Could not read InputFile file " << argv[1] << endl;
		return 1;
	}


	if (inputFile == emptyFile || inputFile == invalidFile){//it it is empty oor has invalid lines

		outputFile= Graph_obj.CreateEmptyFile(argv[3]);//try to create an empty output file
		if (outputFile == failOpenFile) //check if created successfuly
			cout << " Could not open InputFile file " << argv[1] << endl;
		return 1;
	}
	
	SuggestedUsers_toFollow = Graph_obj.Search_Users_Tofollow(argv[2]);//get the vector with the suggested users to be follow

	//try to pen the output file and write out the suggested users
	outputFile = Graph_obj.CreateOutputFile(argv[3], argv[2], SuggestedUsers_toFollow);

	if (outputFile == failOpenFile) {//check if opened successfuly
		cout << " Could not read OutputFile file " << argv[3] << endl;
		return 1;
	}

	return 1;
}