//------------------------------------------------------------------------------------------------
//
// File: edge.h
//  Author: judithantonio
// Date: April 26, 2016
//* NetID : judithantonio
// Description: Definition of the edge class
//
//------------------------------------------------------------------------------------------------

#ifndef EDGE_H
#define EDGE_H

#include <vector>
#include <string>

using namespace std;

//------------------------------------------------------------------------------------------------

class User; // This is a forward class declaration that defines that a class named
            // Node exists elsewhere. This declaration allows us to use Node*
            // within the Edge class, becuase all pointers have the same size.

//------------------------------------------------------------------------------------------------

class Edge {
private:
	vector<User> EgdestList;//save all the users being followed by a specific user
	
public:
   
   Edge();//defaulf constructor
   void createEgde(string Following);//adds a user to the list of the users being followed
   int getEgdestListSize()const;
   vector<User> getEgdestList()const;//retuns the vector list of users being followed
};

#endif

//------------------------------------------------------------------------------------------------


