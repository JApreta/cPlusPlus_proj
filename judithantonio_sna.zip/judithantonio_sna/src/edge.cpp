#include "edge.h"
#include "graph.h"
#include "user.h"
#include <iostream>
using namespace std;
#include <cmath>
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
//------------------------------------------------------------------------------------------------
//
// File: edge.cpp
// Author: judithantonio
// Date: April 26, 2016
//* NetID : judithantonio
// Description: definiton of the members of edge class
//
//------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------------------------


Edge::Edge()
{
}//default constructor

//creates a vector list of users being folloewd by the username
void Edge::createEgde(string Following)
{
	this->EgdestList.push_back(User(Following));//add the new suer to the list
	
}

//return the size of the edgelist
int Edge::getEgdestListSize() const
{
	return EgdestList.size();
}

//allow acess of the vector list of user being followed out side of the class
vector<User> Edge::getEgdestList() const
{
	return EgdestList;
}





