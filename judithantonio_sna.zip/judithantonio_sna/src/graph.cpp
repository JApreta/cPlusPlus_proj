
#include "edge.h"
#include "graph.h"
#include "user.h"
#include <iostream>
using namespace std;
#include <string>
#include <fstream>
#include <sstream>
#include <vector>
#include <algorithm>
/*/------------------------------------------------------------------------------------------------
//
// File: graph.cpp
// Author: judithantonio
// Date: April 26, 2016
// NetID : judithantonio
// Description:
//
Definition of the methods that:
open the input file verify it is valid or not
creates a graph with the users with an adjlist with the users they are following,
search for new users to be follow by a specific user, check for redundance in the suggst list
sort the suggest list using the conditons specified in the function conditonstosort
Creates an empty output file and an output file with the usres suggested
//------------------------------------------------------------------------------------------------



/------------------------------------------------------------------------------------------------
*/
Graph::Graph()
{
}//default constructor

/************************************************************************************************
This method opens the imput file
read the users names and check if they are valide, check if the username is already part of the usernameList
create new user objects (with the username and an edge object) add them to the Users vector if they are new
add user2 to the list of users being followed by user1
Increament the number of followers of user 2(inDegreeofCentrality) 
and the number of users that user1 is following (outDegreeofCentrality)
*************************************************************************************************/
int Graph::openFile(string Filename) {

	
	istringstream inputLine;// to read from a string
	string line = " ", user1 = "", user2 = "";//to save each line from the file
	ifstream Inputfile;//to read from the file
	bool check1 = false, check2 = false;
	int nodeIndex = -1;
	
	Inputfile.open(Filename.c_str());//try to open the file

	if (!Inputfile.is_open())//if not succeed
		return failOpenFile;

	if (Inputfile.peek() == ifstream::traits_type::eof()) {//check if the input file is empty

		Inputfile.close();//cloce the file
		return emptyFile;
	}

	while (!Inputfile.eof() && getline(Inputfile, line).good()) {//run while it does not reach the end of file and doesn't fail to read a line

		check1 = false, check2 = false;//rest check var for each interaction

		inputLine.str(line);//updated the stringstream with the line read from the file
		
		inputLine >> user1;//get first user name
		inputLine >> user2;//get second user name
		

		if (validate(user1) == true && validate(user2) == true) {// check if both userName are valide, if so...

			if (UsersList.size() == 0) {//for the first two users
				//create a new user with an new edge object and the user name and add to the vector list
				this->UsersList.push_back(User(new Edge(), user1));
				this->UsersList.push_back(User(new Edge(), user2));

				//and the users name to the list of usernames
				this->username.push_back(user1);
				this->username.push_back(user2);

			}
			else {//for the following users

				//check if both already exist in the username list
				check1 = find(this->username.begin(), this->username.end(), user1) != this->username.end();
				check2= find(this->username.begin(), this->username.end(), user2) != this->username.end();

				if (check1 == false){//if user1 is not part of the list

					this->UsersList.push_back(User(new Edge(), user1));//create a new user with an new edge object and the user name and add to the vector list
					this->username.push_back(user1);//add the user1 to the userlist
				}

				if (check2 == 0){//if user2 is not part of the list

					this->UsersList.push_back(User(new Edge(), user2));//create a new user with an new edge object and the user name and add to the vector list
					this->username.push_back(user2);//add the user2 to the userlist
			}
			}

			nodeIndex = getNodeindex(user2);//get the index of the Follower user
			
			if(nodeIndex!=-1){// check if exist on the list

				(*this->UsersList.at(nodeIndex).getadjacentList()).createEgde(user1);//add user1 into the edgelist of user2
				this->UsersList.at(nodeIndex).IncrementoutDegreeofCentrality();//increament the #of users following user1
			}
				
			nodeIndex = getNodeindex(user1);//get the index of user1 on the list
				if (nodeIndex != -1) //if exist
					this->UsersList.at(nodeIndex).IncrementinDegreeofCentrality();//increment the number of followers of user1
			
			user1.clear();//clear user1 to get a new value
			user2.clear();//clear user2 to get a new value
			inputLine.clear();//clear the sstream to get an new line inn the next run	
		}

		else {
			//if the usernames are invalid
			Inputfile.close();//close the file
			return invalidFile;
		}
		
	}
			

		Inputfile.close();//close the file
		return openedFile;
	
}


//this method retuns the index of a username of the vector
int Graph::getNodeindex(string userName)
{
	vector <string>::iterator i = this->username.begin();//set i at the begenning of the vector
	int index;

	i = find(this->username.begin(), this->username.end(), userName);//check if the user name is part of the vectorlist of username
	if (i != this->username.end())//if so
	{
		index = distance(this->username.begin(), i);// find its positions
		return index;//and return it
	}
	
	return -1;//if not return -1
	
}

//
vector<User> Graph::Search_Users_Tofollow(string Username)
{
	int i = 0, j = 0, k = 0;
		int Userindex =0, Userindex_atDepth_2 = 0, Userindex_atDepth_3 = 0,temp_ind=0;

	vector<User> UserTofollow, NewusersToFollow;

	Userindex = getNodeindex(Username);//try to get the index of the given username on the vectorlist 
	
	if (Userindex != -1) {//if it is part of the list

		for (i = 0; i < this->UsersList.at(Userindex).getoutDegreeofCentrality(); i++)//for all q estao a ser seguidos
		{
			
			Userindex_atDepth_2 =//get the index of each users at the depht 2
				getNodeindex((*this->UsersList.at(Userindex).getadjacentList()).getEgdestList().at(i).getuserName());

			//for each user at depht2 place the users that they follow in a temporary vector
			for (j = 0; j < this->UsersList.at(Userindex_atDepth_2).getoutDegreeofCentrality(); j++) {

				UserTofollow.push_back((*this->UsersList.at(Userindex_atDepth_2).getadjacentList()).getEgdestList().at(j));

				temp_ind = getNodeindex(UserTofollow.at(UserTofollow.size() - 1).getuserName());

				if (temp_ind != -1) {//upade the followers and folling # of the users in the new list
					UserTofollow.at(UserTofollow.size() - 1).setinDegreeofCentrality(UsersList.at(temp_ind).getinDegreeofCentrality());
					UserTofollow.at(UserTofollow.size() - 1).setoutDegreeofCentrality(UsersList.at(temp_ind).getoutDegreeofCentrality());
				}

				Userindex_atDepth_3 =//get the index of each users at the depht 3
					getNodeindex((*this->UsersList.at(Userindex_atDepth_2).getadjacentList()).getEgdestList().at(j).getuserName());

				//for each user at 3 place the users that they follow in a temporary vector
				for (k = 0; k < this->UsersList.at(Userindex_atDepth_3).getoutDegreeofCentrality(); k++) {

					UserTofollow.push_back((*this->UsersList.at(Userindex_atDepth_3).getadjacentList()).getEgdestList().at(k));

					temp_ind = getNodeindex(UserTofollow.at(UserTofollow.size() - 1).getuserName());
					if (temp_ind != -1) {//upade the followers and folling # of the users in the new list
						UserTofollow.at(UserTofollow.size() - 1).setinDegreeofCentrality(UsersList.at(temp_ind).getinDegreeofCentrality());
						UserTofollow.at(UserTofollow.size() - 1).setoutDegreeofCentrality(UsersList.at(temp_ind).getoutDegreeofCentrality());
					}
				}

			}
		}
	
	
		NewusersToFollow = selectNew_Users_Tofollow(UserTofollow, Userindex);//get the new users to be follow the ones the user isn't following already
	}
	return NewusersToFollow;
}

//this method select the new suggestion to be follow from all founded
vector<User> Graph::selectNew_Users_Tofollow(vector<User> toselect, int Userindex)
{

	int flag = 0,j=0;
	unsigned i = 0;
	vector<User> NewusersToFollow;

	for (i = 0; i < toselect.size(); i++) {//for all suggested users
		flag = 0;//reset for new check
		for (j = 0; j < this->UsersList.at(Userindex).getoutDegreeofCentrality(); j++) {//in the list of the users being followed by the given username

			if (toselect.at(i).getuserName()//check if there some redundance
				== (*this->UsersList.at(Userindex).getadjacentList()).getEgdestList().at(j).getuserName()
				|| toselect.at(i).getuserName()
				== (UsersList.at(Userindex).getuserName()))
				flag++;//flag up if there is a redundance
		}
		if (flag == 0)//if not
			NewusersToFollow.push_back(toselect.at(i));// add the new user to be follow in the list of suggestion


	}

	SortUsersTofollow(NewusersToFollow);// sort the vector with the new suggetsions
	return NewusersToFollow;//and return it
}

//this function creates an output file and write out the users to be followed on it
int Graph::CreateOutputFile(string Filename, string UserName, vector<User> NewusersToFollow) {

	unsigned int i = 0;
	int index = 0;
	ofstream Outputfile;

	Outputfile.open(Filename.c_str());//try to open the file

	if (!Outputfile.is_open())//check if succeed
		return failOpenFile;

	else {//if so

		index = getNodeindex(UserName);//try to get the index of the given username if it is part of the list

		if (index != -1){//if so...
			//NewusersToFollow aux = usersTofollow;
		//vector<User> aux = Search_Users_Tofollow(UserName);//get the vectorist of user to be follow

			//prit out the given username with its indegreeof centrality
		Outputfile << "Looking for new accounts for " << UsersList.at(index).getuserName()
			<< '(' << UsersList.at(index).getinDegreeofCentrality() << ") to follow" << endl;

	///*then print out the user to be follow with the corresponding indegree of centrality
	for (i = 0; i < NewusersToFollow.size(); i++)

			Outputfile << NewusersToFollow.at(i).getuserName() << " (" << NewusersToFollow.at(i).getinDegreeofCentrality() << ')' << endl;

		}
		}

	
	Outputfile.close();//close the file
	return openedFile;
}

//this method creates an empty outputfile
int Graph::CreateEmptyFile(string Filename)
{
	ofstream Emptyfile;
	Emptyfile.open(Filename.c_str());

	if (Emptyfile.is_open()) {
		Emptyfile.close();
		return openedFile;
	}
	else
		return failOpenFile;
}

//this method check if the input usernames are valid with alphanumeric chars and size<=15
bool Graph::validate(string userName)
{
	unsigned int i = 0;
	int chck = 0;
	bool valid = false;

	for (i = 0; i <userName.size(); i++) {//for all char of the string
		if (!isalnum(userName.at(i)) && userName.at(i)!='_')//check if they are alphanum or _
			chck++;//update chck to flag string state
	}
	if (chck == 0 && userName.size() <= 15)//if it has the ridgt size an rigth chars
		valid = true;

	return valid;
}

//this method sort the vector with the suggested user to be followed by higher indegreeofcentrality or alphabetically
void Graph::SortUsersTofollow(vector<User>& tosort)
{
	
	sort(tosort.begin(), tosort.end(),sortConditions);//use the built in sort function with the sortcondtion function to sort the vector with the users to be followed

}

//this method convert to lower case the usrname
string Graph::converttolowercase(string word)
{
	unsigned int  i = 0;
	string aux = "";
	for (i = 0; i < word.length(); i++)//for all letter in the word
		aux = aux + static_cast<char> (tolower(word[i]));//convert it to lower case
	return aux;
}

//this function provides the comparison condition for the sort function
bool sortConditions(User X, User Y)
{
	bool check = false;
	Graph obj;
	if (X.getinDegreeofCentrality() >  Y.getinDegreeofCentrality())//check which user has the higher indegree of centrality
		check = true;
	//if they have the same in degree of centrality check who has the least name alphabetically
	if ((X.getinDegreeofCentrality() == Y.getinDegreeofCentrality()) && (obj.converttolowercase(X.getuserName()) < obj.converttolowercase(Y.getuserName()))) {
		check = true;

	}

	return check;

}