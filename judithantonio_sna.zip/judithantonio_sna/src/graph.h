//------------------------------------------------------------------------------------------------
//
// File: graph.h
// Author: judithantonio
// Date: April 26, 2016
//* NetID : judithantonio
// Description: Definition of the class graph
//
//------------------------------------------------------------------------------------------------

#ifndef GRAPH_H
#define GRAPH_H

#include <vector>
#include <algorithm>
#include "user.h"

using namespace std;
#define failOpenFile 1
#define openedFile 0
#define emptyFile 2
#define invalidFile 3
class Graph {
private:
   
   vector<User> UsersList;//vector with all users 
   vector<string>username;//vector with all usernames works as an aux var to get the users index
public:
   Graph();
   int openFile(string Filename);//open the inputfile and creates the graph
   int getNodeindex(string userName);//get the index of the given username on the gaph
   vector< User> Search_Users_Tofollow(string Username);//search for users to be follow
   vector< User> selectNew_Users_Tofollow(vector< User> toselect, int Userindex);//this method select the new suggestion to be follow from all founded
   int CreateOutputFile(string Filename, string UserName, vector<User> NewusersToFollow);//creates an output file with the suggested users to follow
   int CreateEmptyFile(string Filename);//creates an empty output file
   bool validate(string userName);//check if the usernams are valid
   void SortUsersTofollow(vector<User>& tosort); // this method sort the vector with the suggested users using the given conditions
   
   string converttolowercase(string word);//this method convert to lower case the usrname
   
};

bool sortConditions(User X, User Y);//this function provides the comparison condition for the sort function
#endif

//------------------------------------------------------------------------------------------------


